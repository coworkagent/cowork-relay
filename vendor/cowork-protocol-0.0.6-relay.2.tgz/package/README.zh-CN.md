# Cowork Protocol

候选版本 **0.0.6-relay.2** 新增独立的[加密中继传输](relay/V1-CONTRACT.md)
以及 `@cowork/protocol/relay/control` schema。中继认证不替代已配对电脑的 TLS
身份验证或 Remote 授权。本候选版本尚未发布，已有 Remote 与 Bridge 契约保持不变。

版本 0.0.5 支持协商后从最新消息向前分页：客户端可以先显示最近内容，再按需读取更早的消息。已有客户端保留原有分页行为。

可选的[已配对电脑局域网发现](remote/DISCOVERY.md)帮助客户端在地址变化后找到原电脑。
地址声明由已配对电脑的身份签名；设备发现不会授予权限，也不会替代 TLS 校验。

[English](README.md)

Cowork 客户端与 Host 共用的语言无关 JSON Schema 和一致性样例。公开 Remote 与私有 Host Bridge
分别导出、分别版本化。此仓库不执行 Agent、不存储会话、不认证设备，也不实现网络传输。

**版本 0.0.5** 新增带签名的局域网端点发现与相邻历史分页，保留双语产品展示、原始会话内容和旧投影回退。
M0 保持不变，独立 v1 schema 新增会话命令、持久接收回执、审批、
提问、有界快照与历史、认证后的事件恢复和资源流。契约存在不代表所有消费端都已发布对应功能。浏览器凭据
仍不属于本次实现。npm 包保持 private，许可标记为 `UNLICENSED`；通过 GitHub Release 分发版本化归档，
不发布到公开 npm 仓库。

## 契约入口

| 导出 | 契约 |
| --- | --- |
| `@cowork/protocol/remote` | `remote/m0.schema.json`；Remote 为 `cowork.remote/1-m0`，邀请为 `cowork.pairing/1-m0` |
| `@cowork/protocol/bridge` | `bridge/m0.schema.json`；私有 Bridge 为 `cowork.bridge/1-m0` |
| `@cowork/protocol/remote/constants` | 从 schema 派生的版本、路径、错误码和请求上限 |
| `@cowork/protocol/bridge/constants` | 从 schema 派生的 Bridge 版本、帧上限和帧头长度 |
| `@cowork/protocol/remote/v1` | Remote `cowork.remote/1` schema 与自动生成的 TypeScript DTO 声明 |
| `@cowork/protocol/remote/v1/constants` | 从 schema 派生的 v1 限制、路径、错误码和方法映射 |
| `@cowork/protocol/bridge/v1` | 私有 Bridge `cowork.bridge/1` schema |
| `@cowork/protocol/bridge/v1/constants` | 从 schema 派生的 v1 私有帧常量 |

Schema 使用 JSON Schema draft 2020-12。`.invalid` 域名的 `$id` 仅是标识，不是网络接口；校验器应注册
本地文件，不能从该地址下载。Remote 不依赖 Bridge；Bridge 引用 Remote DTO，应先注册 Remote。
原生实现可直接消费 JSON，无需执行 JavaScript。少量 JavaScript 常量适配器没有另一套手写协议，也没有
运行时依赖。

Remote 的主要 `$defs` 为 `pairingInvitation`、`pairingCandidateRequest`、`pairingCandidateResponse`、
`pairingClaimRequest`、`pairingClaimResponse`、`helloRequest`、`helloResponse`、`error`、
`pairingErrorResponse`、`rpcErrorResponse`。应按预期的具名定义校验，不能只校验文档根部的联合类型。
Bridge 的定义为 `hello`、`bootstrap`、`ready`、`request`、`response`、`frame`。

## M0 交互

1. 用户在电脑打开配对。邀请包含 HTTPS origin、安装身份、叶证书 SHA-256、仅适用于此 Host 的 CA DER
   base64、短期 pairing ID 和一次性 256 位邀请秘密。证书与指纹是公开信任材料；邀请秘密必须保密，邀请
   中不能包含长期设备凭据。
2. 原生客户端通过平台 TLS 针对此 Host 的 CA 验证证书链、主机名和有效期，并核对叶证书指纹，之后才发送
   秘密。读取邀请或比对指纹本身不能替代 TLS；浏览器也不能用本契约跳过证书验证。
3. `POST /remote/v1/pairing/candidates` 登记原生候选设备。响应提供独立候选秘密与六位核对码，用户应在
   两端核对。短码不是认证凭据。批准操作只在电脑进行，不属于 Remote 或 Bridge 方法。
4. `POST /remote/v1/pairing/claim` 证明持有候选秘密；仅已批准候选可领取原生凭据。Host 必须落实过期、
   候选数限制、一次性批准及同设备领取恢复，不能在重试时创建第二个设备登记。
5. `POST /remote/v1/rpc` 在 M0 中只接受 `connection.hello`，要求通过 `Authorization: Bearer` 提交原生
   凭据。响应包含认证后的设备、Host 身份、授权版本和限制；协商能力列表为空，不表示会话执行已可用。

凭据不能放进 URL。认证、到期和撤销由 Host 决定，actor 从真实凭据解析，不能由请求体自报。Gateway 和
Host 都应校验各自边界。配对错误为 `{ error }`；存在有效关联 ID 时，RPC 错误为 `{ traceId, error }`；
请求尚未解析出有效 ID 时，传输拒绝可用 `{ error }`。错误码以 schema 为准，不传输原始异常或文件路径。

## 私有 Bridge

原有 Node M0 适配器使用继承的双向文件描述符 3；Rust 使用继承的 stdin/stdout 管道，stdout 仅承载帧。
M0 每帧是四字节无符号大端长度加对应长度的 UTF-8 JSON。应在缓存载荷前
拒绝零长度、无效 UTF-8 和超过 65,536 字节的长度；HTTP 请求体上限为 16,384 字节。Schema 字符数限制
不能替代传输层的字节数限制。

子进程先发送含启动 nonce 的 `hello`；Host 返回同 nonce 的 `bootstrap`，附选定 IPv4 监听地址与 TLS
材料。子进程校验后才可监听，并发送 `ready`。nonce 经受控环境变量传递，不能放入命令行参数。TLS 私钥
只通过私有通道传递，禁止日志记录。父进程管道 EOF 后，子进程关闭监听并退出；进程边界不是 OS 沙箱。

请求仅允许 `pairing.candidate`、`pairing.claim`、`connection.hello`。hello 必须提供 `authRef`，配对
不能提供；其内容是交给 Host 验证的不透明凭据。hello 的 payload 和 result 均为完整 Remote envelope。
响应按 `bridgeRequestId` 对应请求，调用方还须按原方法的预期定义校验 result。M0 没有通用事件或本地管理
帧；Host 在本地撤销设备，后续认证必须失败。

## 验证与维护

```sh
npm ci
npm run check
npm pack --dry-run
```

检查通过严格模式的 Ajv 2020-12 与 `ajv-formats` 验证 schema 和样例，拒绝未知字段，并确认校验不会修改
输入。JavaScript 适配器执行语法与运行时检查。V1 DTO 声明与方法映射从唯一 schema 自动生成，
`npm run generate:check` 检查漂移。TypeScript 数组即使未展开为定长元组，也必须执行 schema 的运行时
长度检查。开发依赖已有 lockfile，语言无关消费者不需要这些依赖。

样例外层包含 `schema`、`reason`、`value`，校验对象为 `value`。所有秘密、地址、证书和私钥均为合成值。
PEM/DER 样例故意只用于结构校验，不是真实有效证书。Schema 不能验证随机性、TLS 信任、凭据有效性、当前
时间、批准状态、限流或进程生命周期；消费者必须分别验证这些行为。

修改 schema 时同步更新样例。M0 不兼容变更必须协调消费者，不能将预发布版本视为冻结 v1。工程不依赖相邻
checkout 或桌面源码；本地联调通过显式打包和安装归档完成，并记录提交与归档摘要。npm scope 和发布渠道
尚未确定。

校验器依据：[Ajv JSON Schema 支持](https://ajv.js.org/json-schema.html)、
[格式校验](https://ajv.js.org/guide/formats.html)。

## v1 使用

可选能力协商提供电脑当前是否允许远程执行，以及已授权项目不可用的原因。兼容客户端可在提交操作前说明
限制，无需接收本地路径或原始设置。旧客户端继续收到原有 hello 和可用项目响应；新客户端可以连接旧 Host，
此时执行策略状态为未知。[v1 契约指南](remote/V1-CONTRACT.md#optional-policy-and-project-availability-negotiation)
规定显式选择这些字段的方式与兼容规则。状态投影不能替代实际授权检查。

可选会话执行能力允许已授权客户端读取当前模型与权限模式，并为单个空闲会话修改权限，不改变电脑默认值。
修改通过持久命令和版本检查完成；不支持此能力的 Host 保持原有行为。

[v1 契约指南](remote/V1-CONTRACT.md) 明确二十八种方法、实体投影、命令回执状态、SSE 游标恢复和私有资源块。
读取与订阅控制成功返回 HTTP 200；写命令持久接收返回 HTTP 202，不代表命令或 Agent 已完成。结果未知时，
不能用新 commandId 自动重发。只有成功应用事件后才能推进游标；epoch、授权或范围改变必须重新订阅并获取
快照。

```ts
import type { V1Request, V1Response, SessionSnapshot, V1MethodMap } from "@cowork/protocol/remote/v1";
```

V1 Bridge 显式引用保持不变的 M0 配对定义；校验器在本地注册 Remote M0、Remote v1 与 Bridge v1。
V1 限制为请求 64 KiB、响应 512 KiB、事件 32 KiB、私有帧 1 MiB、资源块 16 KiB、资源 10 MiB。
序列化字节限制独立于 schema 字符数限制。原生传输必须保留平台 TLS 验证和按 Host 限定的信任范围。

可选的创建与模型能力支持在电脑管理的目录中创建普通会话、新建项目，并为单个会话选择模型和权限。
新增创建权限必须在电脑明确授权；已有项目的控制权限不会变成任意文件系统访问权。
模型目录只包含不透明选项标识和显示名称，不包含连接秘密。这些扩展通过明确协商与请求参数保留旧响应形状。
所有权、幂等与兼容规则见[实施契约](remote/V1-CONTRACT.md)。

`0.0.0-v1.5` 新增可选 `message.thinking.v1` 能力。订阅与历史请求显式启用后，可显示电脑上已公开可见的
思考正文、折叠状态和有界预览；只读 `messages.thinking` 方法分页读取完整可见正文。
继续执行原有读取权限与凭据脱敏，不包含隐藏上下文、系统提示词、工具原始入参或加密推理。
旧客户端继续收到原来的消息与事件形状。契约支持不代表消费端应用已发布对应功能，详见
[可见思考与分页契约](remote/V1-CONTRACT.md#visible-thinking-and-complete-text-paging)。

`0.0.0-v1.6` 增加显式协商的思考代次标识：普通刷新保留阅读状态，回复重试后清除上一轮已读取内容。
旧版思考订阅继续收到原有响应结构。

包 v1.7 增加显式协商的 `message.activity.v1` 回合分组与 Host 同源用时，
以及 `session.attention.v1` 下仅查询已授权会话的 `sessions.attention` 分页读取。
旧订阅和历史读取保持原形状；计时和游标边界见 `remote/V1-CONTRACT.md`。

工作区读取采用显式协商和独立设备授权，支持浏览目录、分块读取源码，以及查看指定范围的改动和差异，
不增加文件系统写入权限。旧设备授权保持不变。详见[工作区契约](remote/V1-CONTRACT.md#workspace-reading-extension)。
