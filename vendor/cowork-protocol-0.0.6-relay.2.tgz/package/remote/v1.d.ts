/* 从 Remote v1 schema 自动生成，请勿手工修改。 */

export type RemoteV1 =
  | V1Request
  | V1Response
  | RemoteEvent
  | EventRecord
  | EventsPollRequest
  | EventsPollResult
  | AssetUploadChunkRequest
  | AssetUploadChunkResult
  | AssetReadChunkRequest
  | AssetReadChunkResult;
export type V1Request =
  | ConnectionHelloRequest
  | ProjectsListRequest
  | SessionsListRequest
  | SessionsCreateRequest
  | EventsOpenRequest
  | EventsCloseRequest
  | SessionsSnapshotRequest
  | SessionsHistoryRequest
  | MessagesSendRequest
  | TurnsAbortRequest
  | QueuesResumeRequest
  | QueuesCancelRequest
  | ApprovalsRespondRequest
  | QuestionsAnswerRequest
  | CommandsGetRequest
  | AssetsUploadRequest
  | AssetsReadRequest
  | SessionsExecutionRequest
  | SessionsConfigureRequest
  | ProjectsCreateRequest
  | ModelsListRequest
  | MessagesThinkingRequest
  | SessionsAttentionRequest
  | WorkspaceListRequest
  | WorkspaceReadRequest
  | WorkspaceChangesRequest
  | WorkspaceDiffRequest
  | WorkspaceBranchesRequest;
export type RemoteProtocol = 'cowork.remote/1';
export type Id = string;
export type Cursor = string;
export type SessionsCreateParams =
  | {
      projectId: Id;
      executionMode: 'local' | 'worktree';
      title?: string;
    }
  | {
      projectId: null;
      executionMode: 'local';
      title?: string;
    };
export type CommandId = string;
export type MessagesSendParams =
  | {
      sessionId: Id;
      mode: 'start';
      expectedTurnId: null;
      text: string;
      /**
       * @minItems 0
       * @maxItems 16
       */
      assetIds: Id[];
    }
  | {
      sessionId: Id;
      mode: 'queue';
      expectedTurnId: Id;
      text: string;
      /**
       * @minItems 0
       * @maxItems 16
       */
      assetIds: Id[];
    }
  | {
      sessionId: Id;
      mode: 'steer';
      expectedTurnId: Id;
      text: string;
      /**
       * @minItems 0
       * @maxItems 16
       */
      assetIds: Id[];
    };
export type Revision = string;
export type QuestionAnswer =
  | {
      optionIndex: number;
    }
  | {
      text: string;
    };
export type DisplayName = string;
export type MediaType = string;
export type Sha256 = string;
export type PermissionMode = 'ask' | 'acceptEdits' | 'yolo' | 'full';
export type WorkspaceDirectoryPath = '' | WorkspacePath;
export type WorkspacePath = string;
export type WorkspaceRevision = string;
export type WorkspaceView = 'unstaged' | 'staged' | 'branch' | 'last-turn';
export type WorkspaceRef = string;
export type V1Response = QueryResponse | WriteResponse | ErrorResponse;
export type ConnectionHelloResult = ConnectionHelloResult1;
export type Capability =
  | 'commands.v1'
  | 'events.sse.v1'
  | 'session.queue.v1'
  | 'session.steer.v1'
  | 'approval.once.v1'
  | 'assets.stream.v1'
  | 'execution.policy.v1'
  | 'projects.availability.v1'
  | 'session.execution.v1'
  | 'sessions.scratch.v1'
  | 'projects.create.v1'
  | 'session.models.v1'
  | 'message.thinking.v1'
  | 'message.thinking.versioned.v1'
  | 'message.activity.v1'
  | 'session.attention.v1'
  | 'workspace.read.v1'
  | 'display.localized.v1'
  | 'session.history.backward.v1';
export type DeviceCapability =
  | 'read'
  | 'control'
  | 'approve-once'
  | 'assets.read'
  | 'assets.upload'
  | 'sessions.create'
  | 'projects.create'
  | 'workspace.read';
export type MaxRequestBytes = 65536;
export type MaxResponseBytes = 524288;
export type MaxBridgeFrameBytes = 1048576;
export type MaxEventBytes = 32768;
export type MaxAssetBytes = 10485760;
export type MaxAssetChunkBytes = 16384;
export type ExecutionPolicy =
  | {
      canExecute: true;
    }
  | {
      canExecute: false;
      reason: 'full-access' | 'sandbox-disabled' | 'host-policy';
    };
export type UtcTime = string;
export type MessageBlock =
  | {
      type: 'text';
      text: string;
    }
  | {
      type: 'tool';
      tool: ToolActivityView;
    }
  | {
      type: 'asset';
      asset: AssetRef;
    }
  | ThinkingBlock;
export type Milliseconds = number;
export type CommandView =
  | {
      receipt: CommandReceipt;
      status: 'accepted';
      recoveryRequired: boolean;
      revision: Revision;
    }
  | {
      receipt: CommandReceipt;
      status: 'dispatching';
      recoveryRequired: boolean;
      revision: Revision;
    }
  | {
      receipt: CommandReceipt;
      status: 'terminal';
      recoveryRequired: boolean;
      revision: Revision;
      outcome: 'succeeded' | 'failed' | 'cancelled' | 'uncertain';
      result?: CommandResult;
      error?: Error;
    };
export type CommandReceipt = CommandReceipt1;
export type WorkspaceName = string;
export type WorkspaceBytes = WorkspaceBytes1 & WorkspaceBytes2;
export type WorkspaceBytes1 = string;
export type WorkspaceBytes2 = string;
export type WorkspaceUnavailableReason =
  'not-repository' | 'no-base' | 'no-last-turn' | 'unsupported' | 'file-unavailable' | 'snapshot-unavailable';
export type RemoteEvent =
  | {
      type: 'session.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId?: Id;
      payload: {
        session: SessionSummary;
      };
    }
  | {
      type: 'message.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        message: MessageView;
      };
    }
  | {
      type: 'turn.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        activeTurn: TurnView | null;
        revision: Revision;
      };
    }
  | {
      type: 'queue.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        queue: QueueView;
      };
    }
  | {
      type: 'approval.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        /**
         * @minItems 0
         * @maxItems 32
         */
        approvals: ApprovalView[];
        revision: Revision;
      };
    }
  | {
      type: 'question.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        /**
         * @minItems 0
         * @maxItems 32
         */
        questions: QuestionView[];
        revision: Revision;
      };
    }
  | {
      type: 'command.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId?: Id;
      payload: {
        command: CommandView;
      };
    }
  | {
      type: 'asset.updated';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      sessionId: Id;
      payload: {
        asset: AssetRef;
      };
    }
  | {
      type: 'stream.resync-required';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      payload: {
        code:
          | 'schema-invalid'
          | 'method-unsupported'
          | 'protocol-incompatible'
          | 'pairing-unavailable'
          | 'pairing-expired'
          | 'pairing-rejected'
          | 'candidate-pending'
          | 'candidate-invalid'
          | 'auth-required'
          | 'auth-expired'
          | 'access-denied'
          | 'rate-limited'
          | 'host-unavailable'
          | 'internal-error'
          | 'invalid-request'
          | 'not-found'
          | 'method-not-allowed'
          | 'payload-too-large'
          | 'request-timeout'
          | 'storage-unavailable'
          | 'storage-incompatible'
          | 'command-not-ready'
          | 'execution-uncertain'
          | 'idempotency-conflict'
          | 'receipt-expired'
          | 'session-busy'
          | 'stale-turn'
          | 'already-ended'
          | 'capability-unavailable'
          | 'queue-stale'
          | 'already-resolved'
          | 'request-stale'
          | 'history-resync-required'
          | 'resync-required'
          | 'subscription-expired'
          | 'asset-invalid'
          | 'asset-incomplete'
          | 'asset-not-found'
          | 'digest-mismatch'
          | 'cursor-invalid'
          | 'scope-changed'
          | 'command-not-found'
          | 'recovery-required';
      };
    }
  | {
      type: 'auth.expired';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      payload: {
        code:
          | 'schema-invalid'
          | 'method-unsupported'
          | 'protocol-incompatible'
          | 'pairing-unavailable'
          | 'pairing-expired'
          | 'pairing-rejected'
          | 'candidate-pending'
          | 'candidate-invalid'
          | 'auth-required'
          | 'auth-expired'
          | 'access-denied'
          | 'rate-limited'
          | 'host-unavailable'
          | 'internal-error'
          | 'invalid-request'
          | 'not-found'
          | 'method-not-allowed'
          | 'payload-too-large'
          | 'request-timeout'
          | 'storage-unavailable'
          | 'storage-incompatible'
          | 'command-not-ready'
          | 'execution-uncertain'
          | 'idempotency-conflict'
          | 'receipt-expired'
          | 'session-busy'
          | 'stale-turn'
          | 'already-ended'
          | 'capability-unavailable'
          | 'queue-stale'
          | 'already-resolved'
          | 'request-stale'
          | 'history-resync-required'
          | 'resync-required'
          | 'subscription-expired'
          | 'asset-invalid'
          | 'asset-incomplete'
          | 'asset-not-found'
          | 'digest-mismatch'
          | 'cursor-invalid'
          | 'scope-changed'
          | 'command-not-found'
          | 'recovery-required';
      };
    }
  | {
      type: 'access.changed';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      payload: {
        code:
          | 'schema-invalid'
          | 'method-unsupported'
          | 'protocol-incompatible'
          | 'pairing-unavailable'
          | 'pairing-expired'
          | 'pairing-rejected'
          | 'candidate-pending'
          | 'candidate-invalid'
          | 'auth-required'
          | 'auth-expired'
          | 'access-denied'
          | 'rate-limited'
          | 'host-unavailable'
          | 'internal-error'
          | 'invalid-request'
          | 'not-found'
          | 'method-not-allowed'
          | 'payload-too-large'
          | 'request-timeout'
          | 'storage-unavailable'
          | 'storage-incompatible'
          | 'command-not-ready'
          | 'execution-uncertain'
          | 'idempotency-conflict'
          | 'receipt-expired'
          | 'session-busy'
          | 'stale-turn'
          | 'already-ended'
          | 'capability-unavailable'
          | 'queue-stale'
          | 'already-resolved'
          | 'request-stale'
          | 'history-resync-required'
          | 'resync-required'
          | 'subscription-expired'
          | 'asset-invalid'
          | 'asset-incomplete'
          | 'asset-not-found'
          | 'digest-mismatch'
          | 'cursor-invalid'
          | 'scope-changed'
          | 'command-not-found'
          | 'recovery-required';
      };
    }
  | {
      type: 'server.stopping';
      version: 1;
      required: true;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      payload: {
        code:
          | 'schema-invalid'
          | 'method-unsupported'
          | 'protocol-incompatible'
          | 'pairing-unavailable'
          | 'pairing-expired'
          | 'pairing-rejected'
          | 'candidate-pending'
          | 'candidate-invalid'
          | 'auth-required'
          | 'auth-expired'
          | 'access-denied'
          | 'rate-limited'
          | 'host-unavailable'
          | 'internal-error'
          | 'invalid-request'
          | 'not-found'
          | 'method-not-allowed'
          | 'payload-too-large'
          | 'request-timeout'
          | 'storage-unavailable'
          | 'storage-incompatible'
          | 'command-not-ready'
          | 'execution-uncertain'
          | 'idempotency-conflict'
          | 'receipt-expired'
          | 'session-busy'
          | 'stale-turn'
          | 'already-ended'
          | 'capability-unavailable'
          | 'queue-stale'
          | 'already-resolved'
          | 'request-stale'
          | 'history-resync-required'
          | 'resync-required'
          | 'subscription-expired'
          | 'asset-invalid'
          | 'asset-incomplete'
          | 'asset-not-found'
          | 'digest-mismatch'
          | 'cursor-invalid'
          | 'scope-changed'
          | 'command-not-found'
          | 'recovery-required';
      };
    }
  | {
      type: 'diagnostic';
      version: 1;
      required: false;
      hostEpoch: Id;
      seq: Revision;
      grantRevision: Revision;
      payload: {
        message: string;
      };
    };
export type EventsPollResult = EventsPollResult1;
export type Base64Chunk = Base64Chunk1 & Base64Chunk2;
export type Base64Chunk1 = {
  [k: string]: unknown;
};
export type Base64Chunk2 = string;
export type AssetUploadChunkResult = AssetUploadChunkResult1;

export interface ConnectionHelloRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'connection.hello';
  params: ConnectionHelloParams;
}
export interface ConnectionHelloParams {
  /**
   * @minItems 1
   * @maxItems 8
   */
  supportedProtocols: string[];
  /**
   * @minItems 0
   * @maxItems 32
   */
  capabilities: string[];
}
export interface ProjectsListRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'projects.list';
  params: ProjectsListParams;
}
export interface ProjectsListParams {
  includeUnavailable?: boolean;
}
export interface SessionsListRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.list';
  params: SessionsListParams;
}
export interface SessionsListParams {
  projectId?: Id;
  cursor?: Cursor;
  limit?: number;
  includeDisplay?: boolean;
}
export interface SessionsCreateRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.create';
  params: SessionsCreateParams;
  commandId: CommandId;
}
export interface EventsOpenRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'events.open';
  params: EventsOpenParams;
}
export interface EventsOpenParams {
  filter: {
    /**
     * @minItems 0
     * @maxItems 50
     */
    sessionIds: Id[];
    /**
     * @minItems 0
     * @maxItems 50
     */
    projectIds: Id[];
  };
  includeThinking?: boolean;
  thinkingVersion?: 2;
  includeActivity?: boolean;
  includeDisplay?: boolean;
  historyDirection?: 'backward';
}
export interface EventsCloseRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'events.close';
  params: EventsCloseParams;
}
export interface EventsCloseParams {
  subscriptionId: Id;
}
export interface SessionsSnapshotRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.snapshot';
  params: SessionsSnapshotParams;
}
export interface SessionsSnapshotParams {
  subscriptionId: Id;
}
export interface SessionsHistoryRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.history';
  params: SessionsHistoryParams;
}
export interface SessionsHistoryParams {
  sessionId: Id;
  cursor?: Cursor;
  limit?: number;
  includeThinking?: boolean;
  thinkingVersion?: 2;
  includeActivity?: boolean;
  includeDisplay?: boolean;
  historyDirection?: 'backward';
}
export interface MessagesSendRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'messages.send';
  params: MessagesSendParams;
  commandId: CommandId;
}
export interface TurnsAbortRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'turns.abort';
  params: TurnsAbortParams;
  commandId: CommandId;
}
export interface TurnsAbortParams {
  sessionId: Id;
  expectedTurnId: Id;
}
export interface QueuesResumeRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'queues.resume';
  params: QueuesResumeParams;
  commandId: CommandId;
}
export interface QueuesResumeParams {
  sessionId: Id;
  expectedTurnId: null;
  expectedQueueRevision: Revision;
  /**
   * @minItems 1
   * @maxItems 100
   */
  queueEntryIds: Id[];
}
export interface QueuesCancelRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'queues.cancel';
  params: QueuesCancelParams;
  commandId: CommandId;
}
export interface QueuesCancelParams {
  sessionId: Id;
  expectedQueueRevision: Revision;
  /**
   * @minItems 1
   * @maxItems 100
   */
  queueEntryIds: Id[];
}
export interface ApprovalsRespondRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'approvals.respond';
  params: ApprovalsRespondParams;
  commandId: CommandId;
}
export interface ApprovalsRespondParams {
  sessionId: Id;
  expectedTurnId: Id;
  requestId: Id;
  requestVersion: Revision;
  decision: 'allow-once' | 'deny';
}
export interface QuestionsAnswerRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'questions.answer';
  params: QuestionsAnswerParams;
  commandId: CommandId;
}
export interface QuestionsAnswerParams {
  sessionId: Id;
  expectedTurnId: Id;
  requestId: Id;
  requestVersion: Revision;
  answer: QuestionAnswer;
}
export interface CommandsGetRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'commands.get';
  params: CommandsGetParams;
}
export interface CommandsGetParams {
  commandId: CommandId;
}
export interface AssetsUploadRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'assets.upload';
  params: AssetsUploadParams;
  commandId: CommandId;
}
export interface AssetsUploadParams {
  sessionId: Id;
  name: DisplayName;
  mediaType: MediaType;
  sizeBytes: number;
  sha256: Sha256;
}
export interface AssetsReadRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'assets.read';
  params: AssetsReadParams;
}
export interface AssetsReadParams {
  sessionId: Id;
  assetId: Id;
}
export interface SessionsExecutionRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.execution';
  params: SessionsExecutionParams;
}
export interface SessionsExecutionParams {
  sessionId: Id;
  includeModel?: true;
}
export interface SessionsConfigureRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.configure';
  params: SessionsConfigureParams;
  commandId: CommandId;
}
export interface SessionsConfigureParams {
  sessionId: Id;
  expectedRevision: Revision;
  permissionMode: PermissionMode | null;
  modelChoiceId?: Id | null;
}
export interface ProjectsCreateRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'projects.create';
  params: ProjectsCreateParams;
  commandId: CommandId;
}
export interface ProjectsCreateParams {
  name: string;
  initGit?: boolean;
}
export interface ModelsListRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'models.list';
  params: ModelsListParams;
}
export interface ModelsListParams {}
export interface MessagesThinkingRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'messages.thinking';
  params: MessagesThinkingParams;
}
export interface MessagesThinkingParams {
  sessionId: Id;
  messageId: Id;
  cursor?: Cursor;
  thinkingVersion?: 2;
}
export interface SessionsAttentionRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'sessions.attention';
  params: SessionsAttentionParams;
}
export interface SessionsAttentionParams {
  cursor?: Cursor;
  limit?: number;
  includeDisplay?: boolean;
}
export interface WorkspaceListRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'workspace.list';
  params: WorkspaceListParams;
}
export interface WorkspaceListParams {
  sessionId: Id;
  path: WorkspaceDirectoryPath;
  cursor?: Cursor;
  limit?: number;
  includeHidden?: boolean;
}
export interface WorkspaceReadRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'workspace.read';
  params: WorkspaceReadParams;
}
export interface WorkspaceReadParams {
  sessionId: Id;
  path: WorkspacePath;
  offset?: number;
  maxBytes?: number;
  expectedRevision?: WorkspaceRevision;
}
export interface WorkspaceChangesRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'workspace.changes';
  params: WorkspaceChangesParams;
}
export interface WorkspaceChangesParams {
  sessionId: Id;
  view: WorkspaceView;
  baseRef?: WorkspaceRef;
  cursor?: Cursor;
  limit?: number;
}
export interface WorkspaceDiffRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'workspace.diff';
  params: WorkspaceDiffParams;
}
export interface WorkspaceDiffParams {
  sessionId: Id;
  path: WorkspacePath;
  view: WorkspaceView;
  baseRef?: WorkspaceRef;
  expectedRevision?: WorkspaceRevision;
  context?: number;
}
export interface WorkspaceBranchesRequest {
  protocol: RemoteProtocol;
  traceId: Id;
  method: 'workspace.branches';
  params: WorkspaceBranchesParams;
}
export interface WorkspaceBranchesParams {
  sessionId: Id;
}
export interface QueryResponse {
  traceId: Id;
  result:
    | ConnectionHelloResult
    | ProjectsListResult
    | SessionsListResult
    | EventsOpenResult
    | EventsCloseResult
    | SessionsSnapshotResult
    | SessionsHistoryResult
    | CommandsGetResult
    | AssetsReadResult
    | SessionsExecutionResult
    | ModelsListResult
    | MessagesThinkingResult
    | SessionsAttentionResult
    | WorkspaceListResult
    | WorkspaceReadResult
    | WorkspaceChangesResult
    | WorkspaceDiffResult
    | WorkspaceBranchesResult;
}
export interface ConnectionHelloResult1 {
  protocol: RemoteProtocol;
  hostId: Id;
  hostEpoch: Id;
  deviceId: Id;
  grantRevision: Revision;
  /**
   * @minItems 0
   * @maxItems 19
   */
  capabilities: Capability[];
  /**
   * @minItems 0
   * @maxItems 8
   */
  permissions: DeviceCapability[];
  limits: {
    maxRequestBytes: MaxRequestBytes;
    maxResponseBytes: MaxResponseBytes;
    maxBridgeFrameBytes: MaxBridgeFrameBytes;
    maxEventBytes: MaxEventBytes;
    maxAssetBytes: MaxAssetBytes;
    maxAssetChunkBytes: MaxAssetChunkBytes;
  };
  executionPolicy?: ExecutionPolicy;
}
export interface ProjectsListResult {
  /**
   * @minItems 0
   * @maxItems 100
   */
  projects: ProjectView[];
}
export interface ProjectView {
  projectId: Id;
  name: DisplayName;
  /**
   * @minItems 0
   * @maxItems 2
   */
  executionModes: ('local' | 'worktree')[];
  unavailableReason?: 'directory-missing' | 'directory-unavailable' | 'archived' | 'execution-unavailable';
}
export interface SessionsListResult {
  /**
   * @minItems 0
   * @maxItems 50
   */
  sessions: SessionSummary[];
  nextCursor: Cursor | null;
}
export interface SessionSummary {
  sessionId: Id;
  projectId: Id;
  title: string;
  revision: Revision;
  status: 'idle' | 'running' | 'interrupted' | 'failed' | 'completed' | 'deleted';
  updatedAt: UtcTime;
  titleDisplay?: LocalizedDisplay;
}
export interface LocalizedDisplay {
  version: number;
  key: string;
  variants: {
    'zh-CN': string;
    en: string;
  };
}
export interface EventsOpenResult {
  subscriptionId: Id;
  hostEpoch: Id;
  grantRevision: Revision;
  expiresAt: UtcTime;
  maxBufferedEvents: number;
  maxBufferedBytes: number;
}
export interface EventsCloseResult {
  closed: true;
}
export interface SessionsSnapshotResult {
  hostEpoch: Id;
  grantRevision: Revision;
  cursor: Cursor;
  /**
   * @minItems 0
   * @maxItems 20
   */
  sessions: SessionSnapshot[];
  truncated: boolean;
}
export interface SessionSnapshot {
  session: SessionSummary;
  /**
   * @minItems 0
   * @maxItems 20
   */
  messages: MessageView[];
  activeTurn: TurnView | null;
  queue: QueueView;
  /**
   * @minItems 0
   * @maxItems 32
   */
  pendingApprovals: ApprovalView[];
  /**
   * @minItems 0
   * @maxItems 32
   */
  pendingQuestions: QuestionView[];
  /**
   * @minItems 0
   * @maxItems 100
   */
  commandRefs: CommandView[];
  historyCursor: Cursor | null;
}
export interface MessageView {
  messageId: Id;
  role: 'user' | 'assistant';
  /**
   * @minItems 0
   * @maxItems 32
   */
  blocks: MessageBlock[];
  revision: Revision;
  truncated: boolean;
  activity?: MessageActivity;
}
export interface ToolActivityView {
  toolCallId: Id;
  displayName: DisplayName;
  summary: string;
  summaryTruncated: boolean;
  status: 'running' | 'succeeded' | 'failed' | 'cancelled';
  /**
   * @minItems 0
   * @maxItems 16
   */
  assets: AssetRef[];
  displayNameDisplay?: LocalizedDisplay;
  summaryDisplay?: LocalizedDisplay;
}
export interface AssetRef {
  assetId: Id;
  sessionId: Id;
  name: DisplayName;
  mediaType: MediaType;
  sizeBytes: number;
  sha256: Sha256;
  canRead: boolean;
  revision: Revision;
}
export interface ThinkingBlock {
  type: 'thinking';
  text: string;
  status: 'running' | 'completed';
  truncated: boolean;
  generation?: string;
}
export interface MessageActivity {
  createdAt: Milliseconds;
  turnId?: Id;
  phase?: 'commentary' | 'final_answer';
  turnTiming?: TurnTiming;
  steer?: true;
  streaming?: boolean;
}
export interface TurnTiming {
  startedAt: Milliseconds;
  endedAt: Milliseconds;
  durationMs: Milliseconds;
}
export interface TurnView {
  turnId: Id;
  status: 'running' | 'stopping' | 'interrupted' | 'succeeded' | 'failed' | 'cancelled';
  revision: Revision;
  activity?: TurnActivity;
}
export interface TurnActivity {
  startedAt: Milliseconds;
  observedAt: Milliseconds;
  elapsedMs: Milliseconds;
}
export interface QueueView {
  revision: Revision;
  paused: boolean;
  /**
   * @minItems 0
   * @maxItems 100
   */
  entries: QueueEntryView[];
}
export interface QueueEntryView {
  queueEntryId: Id;
  text: string;
  textTruncated: boolean;
  /**
   * @minItems 0
   * @maxItems 16
   */
  assetIds: Id[];
  createdAt: UtcTime;
  state: 'pending' | 'paused' | 'started' | 'cancelled';
}
export interface ApprovalView {
  requestId: Id;
  turnId: Id;
  requestVersion: Revision;
  status: 'pending' | 'resolved';
  displayName: DisplayName;
  summary: string;
  summaryTruncated: boolean;
  /**
   * @minItems 0
   * @maxItems 2
   */
  allowedDecisions: ('allow-once' | 'deny')[];
  localOnly: boolean;
  displayNameDisplay?: LocalizedDisplay;
  summaryDisplay?: LocalizedDisplay;
}
export interface QuestionView {
  requestId: Id;
  turnId: Id;
  requestVersion: Revision;
  status: 'pending' | 'resolved';
  title: string;
  prompt: string;
  promptTruncated: boolean;
  kind: 'choice' | 'approval';
  /**
   * @minItems 0
   * @maxItems 20
   */
  options: string[];
  allowText: boolean;
  async: boolean;
  localOnly: boolean;
  recommendedOptionIndex?: number;
  autoPickAt?: UtcTime;
  titleDisplay?: LocalizedDisplay;
  promptDisplay?: LocalizedDisplay;
  /**
   * @maxItems 20
   */
  optionDisplays?: LocalizedDisplay[];
}
export interface CommandReceipt1 {
  commandId: CommandId;
  method:
    | 'sessions.create'
    | 'messages.send'
    | 'turns.abort'
    | 'queues.resume'
    | 'queues.cancel'
    | 'approvals.respond'
    | 'questions.answer'
    | 'assets.upload'
    | 'sessions.configure'
    | 'projects.create';
  state: 'accepted';
  acceptedAt: UtcTime;
  sessionId?: Id;
  turnId?: Id;
  queueEntryId?: Id;
  uploadId?: Id;
  projectId?: Id;
}
export interface CommandResult {
  sessionId?: Id;
  turnId?: Id;
  queueEntryId?: Id;
  uploadId?: Id;
  assetId?: Id;
  /**
   * @minItems 0
   * @maxItems 100
   */
  queueEntryIds?: Id[];
  stopRequested?: boolean;
  upload?: UploadDescriptor;
  projectId?: Id;
}
export interface UploadDescriptor {
  uploadId: Id;
  sessionId: Id;
  sizeBytes: number;
  sha256: Sha256;
  expiresAt: UtcTime;
  chunkBytes: MaxAssetChunkBytes;
}
export interface Error {
  code:
    | 'schema-invalid'
    | 'method-unsupported'
    | 'protocol-incompatible'
    | 'pairing-unavailable'
    | 'pairing-expired'
    | 'pairing-rejected'
    | 'candidate-pending'
    | 'candidate-invalid'
    | 'auth-required'
    | 'auth-expired'
    | 'access-denied'
    | 'rate-limited'
    | 'host-unavailable'
    | 'internal-error'
    | 'invalid-request'
    | 'not-found'
    | 'method-not-allowed'
    | 'payload-too-large'
    | 'request-timeout'
    | 'storage-unavailable'
    | 'storage-incompatible'
    | 'command-not-ready'
    | 'execution-uncertain'
    | 'idempotency-conflict'
    | 'receipt-expired'
    | 'session-busy'
    | 'stale-turn'
    | 'already-ended'
    | 'capability-unavailable'
    | 'queue-stale'
    | 'already-resolved'
    | 'request-stale'
    | 'history-resync-required'
    | 'resync-required'
    | 'subscription-expired'
    | 'asset-invalid'
    | 'asset-incomplete'
    | 'asset-not-found'
    | 'digest-mismatch'
    | 'cursor-invalid'
    | 'scope-changed'
    | 'command-not-found'
    | 'recovery-required';
  retryable: boolean;
}
export interface SessionsHistoryResult {
  sessionId: Id;
  revision: Revision;
  /**
   * @minItems 0
   * @maxItems 50
   */
  messages: MessageView[];
  nextCursor: Cursor | null;
  truncated: boolean;
}
export interface CommandsGetResult {
  command: CommandView;
}
export interface AssetsReadResult {
  asset: AssetRef;
}
export interface SessionsExecutionResult {
  sessionId: Id;
  revision: Revision;
  permissionMode: PermissionMode | null;
  effectivePermissionMode: PermissionMode;
  model: string;
  /**
   * @maxItems 4
   */
  allowedPermissionModes: PermissionMode[];
  modelSelection?: ModelSelection;
}
export interface ModelSelection {
  modelChoiceId: Id | null;
  effectiveModelChoiceId: Id | null;
}
export interface ModelsListResult {
  /**
   * @maxItems 100
   */
  models: ModelChoice[];
  defaultModelChoiceId: Id | null;
}
export interface ModelChoice {
  modelChoiceId: Id;
  label: string;
  providerLabel: string;
}
export interface MessagesThinkingResult {
  sessionId: Id;
  messageId: Id;
  text: string;
  status: 'running' | 'completed';
  nextCursor: Cursor | null;
  generation?: string;
}
export interface SessionsAttentionResult {
  hostEpoch: Id;
  grantRevision: Revision;
  /**
   * @minItems 0
   * @maxItems 50
   */
  items: SessionAttention[];
  nextCursor: Cursor | null;
}
export interface SessionAttention {
  session: SessionSummary;
  /**
   * @minItems 0
   * @maxItems 32
   */
  pendingApprovals: ApprovalView[];
  /**
   * @minItems 0
   * @maxItems 32
   */
  pendingQuestions: QuestionView[];
}
export interface WorkspaceListResult {
  sessionId: Id;
  path: WorkspaceDirectoryPath;
  /**
   * @maxItems 100
   */
  entries: WorkspaceEntry[];
  nextCursor: Cursor | null;
  revision: WorkspaceRevision;
}
export interface WorkspaceEntry {
  name: WorkspaceName;
  path: WorkspacePath;
  kind: 'file' | 'directory' | 'symlink' | 'other';
  sizeBytes?: number;
}
export interface WorkspaceReadResult {
  sessionId: Id;
  path: WorkspacePath;
  sizeBytes: number;
  mediaType: MediaType;
  revision: WorkspaceRevision;
  bytesBase64: WorkspaceBytes;
  offset: number;
  eof: boolean;
}
export interface WorkspaceChangesResult {
  sessionId: Id;
  view: WorkspaceView;
  isRepo: boolean;
  available: boolean;
  unavailableReason?: WorkspaceUnavailableReason;
  baseRef?: WorkspaceRef;
  revision: WorkspaceRevision;
  /**
   * @maxItems 100
   */
  entries: WorkspaceChange[];
  nextCursor: Cursor | null;
  truncated: boolean;
  turnIndex?: number;
}
export interface WorkspaceChange {
  path: WorkspacePath;
  oldPath?: WorkspacePath;
  status: 'modified' | 'added' | 'deleted' | 'renamed' | 'copied' | 'untracked' | 'conflict';
  staged: boolean;
  unstaged: boolean;
  untracked: boolean;
  additions?: number;
  deletions?: number;
}
export interface WorkspaceDiffResult {
  sessionId: Id;
  path: WorkspacePath;
  view: WorkspaceView;
  revision: WorkspaceRevision;
  patch: string;
  binary: boolean;
  truncated: boolean;
  available: boolean;
  unavailableReason?: WorkspaceUnavailableReason;
  baseRef?: WorkspaceRef;
  turnIndex?: number;
}
export interface WorkspaceBranchesResult {
  sessionId: Id;
  isRepo: boolean;
  currentBranch: WorkspaceRef | null;
  /**
   * @maxItems 200
   */
  branches: WorkspaceRef[];
  truncated: boolean;
}
export interface WriteResponse {
  traceId: Id;
  receipt: CommandReceipt;
}
export interface ErrorResponse {
  traceId?: Id;
  error: Error;
}
export interface EventRecord {
  cursor: Cursor;
  event: RemoteEvent;
}
export interface EventsPollRequest {
  subscriptionId: Id;
  after: Cursor;
  maxEvents: number;
}
export interface EventsPollResult1 {
  /**
   * @minItems 0
   * @maxItems 16
   */
  events: EventRecord[];
  closed: boolean;
  error?: Error;
}
export interface AssetUploadChunkRequest {
  uploadId: Id;
  offset: number;
  dataBase64: Base64Chunk;
  eof: boolean;
}
export interface AssetUploadChunkResult1 {
  uploadId: Id;
  offset: number;
  complete: boolean;
  asset?: AssetRef;
}
export interface AssetReadChunkRequest {
  assetId: Id;
  offset: number;
  maxBytes: number;
}
export interface AssetReadChunkResult {
  asset: AssetRef;
  offset: number;
  dataBase64: Base64Chunk;
  eof: boolean;
}

export interface V1MethodMap {
  'connection.hello': { kind: 'read'; params: ConnectionHelloParams; result: ConnectionHelloResult };
  'projects.list': { kind: 'read'; params: ProjectsListParams; result: ProjectsListResult };
  'sessions.list': { kind: 'read'; params: SessionsListParams; result: SessionsListResult };
  'sessions.create': { kind: 'write'; params: SessionsCreateParams; result: CommandReceipt };
  'events.open': { kind: 'control'; params: EventsOpenParams; result: EventsOpenResult };
  'events.close': { kind: 'control'; params: EventsCloseParams; result: EventsCloseResult };
  'sessions.snapshot': { kind: 'read'; params: SessionsSnapshotParams; result: SessionsSnapshotResult };
  'sessions.history': { kind: 'read'; params: SessionsHistoryParams; result: SessionsHistoryResult };
  'messages.send': { kind: 'write'; params: MessagesSendParams; result: CommandReceipt };
  'turns.abort': { kind: 'write'; params: TurnsAbortParams; result: CommandReceipt };
  'queues.resume': { kind: 'write'; params: QueuesResumeParams; result: CommandReceipt };
  'queues.cancel': { kind: 'write'; params: QueuesCancelParams; result: CommandReceipt };
  'approvals.respond': { kind: 'write'; params: ApprovalsRespondParams; result: CommandReceipt };
  'questions.answer': { kind: 'write'; params: QuestionsAnswerParams; result: CommandReceipt };
  'commands.get': { kind: 'read'; params: CommandsGetParams; result: CommandsGetResult };
  'assets.upload': { kind: 'write'; params: AssetsUploadParams; result: CommandReceipt };
  'assets.read': { kind: 'read'; params: AssetsReadParams; result: AssetsReadResult };
  'sessions.execution': { kind: 'read'; params: SessionsExecutionParams; result: SessionsExecutionResult };
  'sessions.configure': { kind: 'write'; params: SessionsConfigureParams; result: CommandReceipt };
  'projects.create': { kind: 'write'; params: ProjectsCreateParams; result: CommandReceipt };
  'models.list': { kind: 'read'; params: ModelsListParams; result: ModelsListResult };
  'messages.thinking': { kind: 'read'; params: MessagesThinkingParams; result: MessagesThinkingResult };
  'sessions.attention': { kind: 'read'; params: SessionsAttentionParams; result: SessionsAttentionResult };
  'workspace.list': { kind: 'read'; params: WorkspaceListParams; result: WorkspaceListResult };
  'workspace.read': { kind: 'read'; params: WorkspaceReadParams; result: WorkspaceReadResult };
  'workspace.changes': { kind: 'read'; params: WorkspaceChangesParams; result: WorkspaceChangesResult };
  'workspace.diff': { kind: 'read'; params: WorkspaceDiffParams; result: WorkspaceDiffResult };
  'workspace.branches': { kind: 'read'; params: WorkspaceBranchesParams; result: WorkspaceBranchesResult };
}
export type Request = V1Request;
export type Response = V1Response;
export type RemoteError = Error;
declare const schema: { readonly $id: string; readonly $defs: Record<string, unknown>; readonly [key: string]: unknown };
export default schema;
