# Remote v1 implementation contract

This document describes the versioned Remote v1 contract. `v1.schema.json` is
the runtime source of truth; generated TypeScript declarations must not be edited manually.
M0 exports and wire behavior remain available separately.

## Adjacent older history extension

Package `0.0.5` adds `session.history.backward.v1`.
Clients offer it in hello and send `historyDirection:"backward"` only when
returned. The option is valid on `events.open` and `sessions.history`.
Gateways and Hosts must support the extension together before advertising it.
Omission retains oldest-first paging for existing clients.

An opted-in snapshot contains the latest messages in chronological order.
Its `historyCursor` identifies the exclusive boundary immediately before
those messages, including when the snapshot byte budget drops older entries.
A backward history request returns the nearest messages before its boundary,
also in chronological order. Without a cursor it starts at the latest end.
`nextCursor` moves toward older messages; null means no earlier messages remain.
Response byte limits may shorten a page from its oldest end. They must not
skip any message between that page and the previously returned boundary.

Cursors remain opaque, expiring, bound to the device, grant revision,
session and direction/projection scope. They bind the older prefix before
the boundary, so appending messages or streaming a newer message does not
invalidate older-history reads. Removing, reordering or editing that prefix
may require a fresh snapshot. Authorization is rechecked for every page.
Clients prepend older pages, deduplicate overlapping messages by identity
and revision, and discard late pages after a session or authorization change.
History reads do not pause live events or replay write commands.

## Localized product display extension

Package `0.0.4` adds `display.localized.v1` without changing
the Remote or Bridge wire identifiers. Clients
request the capability in hello and use `includeDisplay:true` only after the Host
returns it. The option is available on `sessions.list`, `sessions.history`,
`sessions.attention`, and `events.open`. A subscription fixes the choice for its
snapshots and events. Omission or false retains the legacy entity shapes; a Host
must not attach display metadata to those responses or subscriptions.

Opted-in projections may add `titleDisplay` to a session summary and
`displayNameDisplay` / `summaryDisplay` to tool activities and approvals. Questions
may add `titleDisplay`, `promptDisplay`, and `optionDisplays` only for explicit
product-owned templates. An `optionDisplays` array has at most 20 entries and must
have exactly the same length and index meaning as the original `options`; if a
complete mapping is unavailable, the entire optional array is omitted. Hosts and
consumers verify this correspondence. Each descriptor is
`{version,key,variants:{"zh-CN":string,en:string}}`; all three properties and both
language variants are required. Version is an integer 1..255, the key is a bounded
`remote.*` semantic identifier, and each plain-text variant has at most 4096 Unicode
code points. Unknown properties, nested content, arbitrary input and parameters
are forbidden. Producers currently emit version 1; consumers render only version
1 and otherwise use the separate legacy title/displayName/summary. Unknown keys
within version 1 do not require client dictionaries: the text is self-contained.
Future versions must fit this envelope to reach that fallback; unknown shapes
remain schema errors. These are display strings, never HTML or executable templates.

The Host creates variants from its own product templates, selecting and redacting
each authorized display value before projection. Conversation text, generated
questions/options, user names, command output and other third-party content stay
in their original language. Both variants and the legacy fallback count toward
all existing UTF-8 serialized limits. If the complete descriptor cannot fit, omit
it and retain the bounded legacy fallback. Localization never changes request
versions, option indexes, allowed decisions, command payloads or authority.

Strict older validators reject new fields and new hello response capabilities.
SDK, Host and the gateway's pinned schema archive must therefore be upgraded as a
compatible set. A new Host paired with an older gateway must suppress this
capability and extension or require a component update. Capability negotiation
does not authorize any operation. The private Bridge references the same Remote
definitions and adds no separate display schema or language preference.

## Workspace reading extension

Package `0.0.3` adds the negotiated `workspace.read.v1` capability and the
explicit `workspace.read` device permission. Each workspace method requires
that permission, normal `read`, and current session scope. Existing grants do
not gain access automatically. Hello includes the new permission only when
the feature is negotiated; a feature advertisement is not authorization.
No workspace write, staging, checkout, revert or arbitrary-root method exists.

All five methods are read RPCs. Generated `Workspace*Params` and
`Workspace*Result` types describe their exact fields:

- `workspace.list`: paged direct children of a relative directory; empty path
  selects the session workspace root. Limit defaults to 100 and cannot exceed
  100. Hidden entries require `includeHidden:true`; `.git` is always excluded.
- `workspace.read`: a file byte chunk, offset, total byte size, media type,
  opaque revision and EOF. Maximum chunk is 65,536 bytes. Offset defaults to
  zero, maximum bytes defaults to 65,536. An offset above zero requires
  `expectedRevision`. Empty files return an empty chunk with EOF. There is no
  protocol-wide file-size ceiling beyond a JavaScript-safe integer size.
- `workspace.changes`: paged entries for `unstaged`, `staged`, `branch`, or
  `last-turn`, with comparison revision, availability and truncation. Branch
  comparison may include `baseRef`; responses echo a supplied reference.
  Optional addition/deletion counts are omitted when unavailable, not zeroed.
  Last-turn snapshots may exist outside Git; `isRepo:false` therefore does not
  imply `available:false`. Optional `turnIndex` identifies the snapshot turn.
- `workspace.diff`: one path's unified patch for the same comparison scope.
  `expectedRevision` binds the change-list comparison. Context defaults to
  three lines and is bounded to 0..20. Patches are bounded to 131,072 UTF-8
  bytes with an explicit partial flag. Binary and unavailable files are
  represented explicitly. Optional `baseRef` and `turnIndex` carry context.
- `workspace.branches`: at most 200 bounded reference names, nullable current
  branch, Git availability and a truncation flag.

Paths contain at most 4096 Unicode code points and use relative `/` separators.
Absolute paths, empty/dot segments, colons, backslashes, controls and `.git`
segments are invalid. Entry names contain at most 255 code points. These shape
checks do not replace Host containment, symlink, authorization and race checks.
The Host resolves a session-owned root, never a client-selected absolute root,
and reauthorizes after asynchronous work before returning private content.

Workspace revisions are opaque 64-character lowercase hexadecimal strings,
separate from decimal entity revisions. Read revisions identify a file;
changes/diff revisions identify a comparison snapshot. Mismatch returns
`request-stale`. Cursors bind actor, grant, host generation, session, root and
query inputs; stale cursors cannot combine directory or comparison versions.
Clients bind results to requested session, path, scope, reference and revision;
source chunks additionally require matching offset and coherent EOF/size.
The existing 512 KiB serialized-response budget still applies. Availability
reasons are bounded enums, never raw errors or host paths. Cancellation keeps
the ordinary query semantics and does not create a durable command.

## Transport and limits

Protocol `cowork.remote/1`; authenticated `POST /remote/v1/rpc`. Native Bearer
credentials only in this implementation. Read/control success is HTTP 200
`{traceId,result}`; durable write acceptance is HTTP 202 `{traceId,receipt}`;
errors are HTTP 4xx/5xx `{traceId?,error:{code,retryable}}`.
`traceId` is an opaque identifier. All writes require a UUID `commandId`; reads
and subscription controls forbid it. A receipt means durable acceptance only.

Limits: request 65536 bytes; response/snapshot 524288 bytes; event 32768 bytes;
v1 Bridge frame 1048576 bytes; asset chunk 16384 bytes; asset 10485760 bytes.
Bodies, arrays and strings have schema bounds; Host must additionally enforce the
serialized-byte budget. Content shown with `truncated:true` is explicitly partial.

## Read and control parameters/results

- `connection.hello`: `{supportedProtocols:string[],capabilities:string[]}` →
  `{protocol,hostId,hostEpoch,deviceId,grantRevision,capabilities,permissions,limits,executionPolicy?}`.
  `permissions` is the authorized subset of `read|control|approve-once|assets.read|assets.upload`.
  `limits` contains `maxRequestBytes,maxResponseBytes,maxBridgeFrameBytes,
  maxEventBytes,maxAssetBytes,maxAssetChunkBytes` using the constants above.
- `projects.list`: `{includeUnavailable?:boolean}` → `{projects:ProjectView[]}`.
- `sessions.list`: `{projectId?,cursor?,limit?}` → `{sessions:SessionSummary[],nextCursor:string|null}`.
- `sessions.execution`: `{sessionId}` → `{sessionId,revision,permissionMode,effectivePermissionMode,model,allowedPermissionModes}`.
  Requires negotiated `session.execution.v1` and read access to that session.
- `events.open`: `{filter:{sessionIds:string[],projectIds:string[]},includeThinking?:boolean}` →
  `{subscriptionId,hostEpoch,grantRevision,expiresAt,maxBufferedEvents,maxBufferedBytes}`.
  Empty arrays select all currently authorized sessions; otherwise the union of
  selected sessions and projects applies. Requested scope is reauthorized.
- `events.close`: `{subscriptionId}` → `{closed:true}`.
- `sessions.snapshot`: `{subscriptionId}` →
  `{hostEpoch,grantRevision,cursor,sessions:SessionSnapshot[],truncated:boolean}`.
- `sessions.history`: `{sessionId,cursor?,limit?,includeThinking?:boolean}` →
  `{sessionId,revision,messages:MessageView[],nextCursor:string|null,truncated:boolean}`.
- `messages.thinking`: `{sessionId,messageId,cursor?}` →
  `{sessionId,messageId,text,status:"running"|"completed",nextCursor:string|null}`.
  Requires negotiated `message.thinking.v1` and read access; does not require an idle session.
- `commands.get`: `{commandId}` → `{command:CommandView}` for the authenticated actor.
- `assets.read`: `{sessionId,assetId}` → `{asset:AssetRef}`.

## Optional policy and project availability negotiation

Package `0.0.0-v1.2` adds two optional capabilities while retaining the
`cowork.remote/1` wire version. A Host returns each capability only if the client
requested it. A client must accept a legacy hello that omits both capabilities
and the policy field; omission means the policy is unknown, not allowed.

`execution.policy.v1` requires `executionPolicy` in the same hello response;
without this capability the field must be absent. `ExecutionPolicy` is either
`{canExecute:true}` or `{canExecute:false,reason:"full-access"|"sandbox-disabled"|"host-policy"}`.
The allowed state forbids a reason; the blocked state requires one. It reports
the Host's current execution policy without exposing settings or local paths.
Device permissions and project/session grants still apply independently. The
projection is advisory and may become stale; the Host must reauthorize every
operation. Refresh hello after a policy-related rejection or reconnect.

`projects.availability.v1` permits the client to send
`projects.list({includeUnavailable:true})`. Only this explicit opt-in includes
authorized projects with no currently usable execution mode. Clients omit the
parameter when the capability is absent. Omission or `false` preserves the legacy
response: unavailable projects are filtered out. Unavailable entries contain
`executionModes:[]` and a required bounded `unavailableReason` of
`directory-missing|directory-unavailable|archived|execution-unavailable`.
Usable entries contain at least one mode and forbid `unavailableReason`.
Availability does not grant access or permit a command; the Host checks current
availability and authorization again on creation. No unavailable reason carries
an absolute path or raw filesystem error.

These additions are opt-in to preserve strict old clients: an old hello request
receives the old response shape, and an old project-list request receives only
usable projects. Schema checks enforce response field consistency; request/response
capability matching and explicit project-list opt-in are consumer responsibilities.

## Session execution settings

Package `0.0.0-v1.3` adds the optional `session.execution.v1` capability and two
methods without adding fields to existing session snapshots. Clients use these
methods only after the Host returns the requested capability; older Hosts keep
their existing session behavior and do not offer a permission selector.

`PermissionMode` is `ask|acceptEdits|yolo|full`. `sessions.execution` returns a
nullable persisted override (`null` inherits the computer's current default), the
effective mode, the session's model label, and supported modes. Model labels are
bounded display strings, not provider configuration. The settings revision is
independent of message and queue revisions. No credentials or global settings
are exposed.

`sessions.configure` requires control access to the session and an exact
`expectedRevision`. The Host rejects stale revisions with `request-stale` and
active sessions with `session-busy`. It persists only that session's override;
other sessions and the computer's default are unchanged. A terminal successful
command returns `{sessionId}`. Acceptance alone does not establish that the mode
changed; read command completion and then refresh `sessions.execution` before
starting work that depends on the choice. To create with a chosen mode, first
confirm creation, then configure the idle session, then submit the first message.
Do not recreate a confirmed session if configuration or the initial message fails.

Full access is an execution mode, not an automatic denial of remote control.
Device capabilities, session/project scope, fresh authorization and the selected
execution policy still apply. A client must respect an explicit Host policy
rejection; choosing a mode does not add device grants.

Configure command receipts contain a new method value. Hosts must not include
these receipts in legacy session snapshots or event streams. They may omit
configure command projections for every subscriber and use actor-scoped
`commands.get` for completion instead. Settings are refreshed on session entry,
reconnect and after configuration; no new required event type is introduced.

## Ordinary sessions, managed projects and model selection

Package `0.0.0-v1.4` retains the wire version and adds three requested/returned
capabilities: `sessions.scratch.v1`, `projects.create.v1` and `session.models.v1`.
A client uses an extension only after the Host returns its capability. The Host
continues to authorize every request; feature negotiation does not grant authority.

The new device permissions `sessions.create` and `projects.create` are separate
from `control`. Existing device grants do not acquire them automatically. Hello
may return each new permission only when its corresponding feature was negotiated;
a legacy hello therefore retains its original permission vocabulary and shape.
Creating an ordinary session or a project requires its explicit creation permission
and normal control permission. Reading and controlling created resources still
requires the relevant read/control/asset permission.

`sessions.create` accepts its unchanged project branch, or the explicit ordinary
branch `{projectId:null,executionMode:"local",title?}`. Ordinary sessions use a new
Host-managed scratch directory. They cannot request a worktree or supply a path.
Session summaries retain their existing `projectId:"unassigned"` representation
for sessions without a project; this is a projection marker, not an actual project
grant or a project filter. List all authorized sessions and group these entries on
the client, or subscribe using explicit authorized session IDs.

`projects.create` accepts `{name,initGit?}`. The name is 1..240 characters, contains
non-whitespace and forbids control characters. It is a display name, not a path.
The Host allocates a project ID before durable acceptance and returns it in both
the receipt and successful terminal result. The Host selects a managed project
root outside scratch-directory cleanup scope and allocates the child directory;
no remote `cwd`, `parent`, `dir`, `roots` or arbitrary filesystem import exists.
Host filesystem checks must reject unsafe links and must not overwrite existing
directories. Reusing a command ID never creates a second project or directory.

The Host records the authenticated creating device on new ordinary sessions and
managed projects. Creation authority may cover only that device's own created
resources, never arbitrary existing sessions, projects or another device's data.
That authority is rechecked alongside the ordinary action permission for every
read, write, event, asset and queued operation. Removing it immediately removes
this implied scope; independent explicit project/session grants continue to apply.
The client cannot set ownership. A device that is re-paired with a different ID
does not inherit the former device's ownership. Resource creation does not modify
the device's static grant lists or advance its grant revision.

`models.list({})` returns `{models:ModelChoice[],defaultModelChoiceId:Id|null}`.
A choice is `{modelChoiceId,label,providerLabel}`. The list contains at most 100
unique opaque choice IDs; labels contain 1..240 characters. A non-null default ID
must exist in that list. The Host exposes only currently selectable configured
models, never connection URLs, keys, headers, raw provider configuration or an
arbitrary remote model string. A bounded empty list with a null default is valid.
The Host may derive opaque choice IDs from its private provider/model mapping;
the client must refresh the catalog after an unavailable-choice rejection.

With `session.models.v1`, `sessions.execution({sessionId,includeModel:true})`
adds `modelSelection:{modelChoiceId:Id|null,effectiveModelChoiceId:Id|null}` to
its existing result. The first ID is the persisted session override (null inherits
the computer default); the second is the current effective selectable choice,
or null when no current catalog choice represents it. The existing `model` field
remains the effective display label. Without explicit `includeModel:true`, the
extra field must be absent. `false` is not an alternate request form. Consumers
check the request/response opt-in match in addition to schema validity.

`sessions.configure` adds optional `modelChoiceId:Id|null` while retaining its
required `sessionId`, `expectedRevision` and `permissionMode`. Omitting the new
field preserves the existing model override; null restores inheritance. A client
changing only the model sends the currently read permission override. Model and
permission changes share one idle check, revision compare-and-swap and durable
commit. The Host resolves and revalidates the opaque model choice before commit;
unknown or unavailable choices fail with `capability-unavailable`. Selecting a
model affects actual execution for that session and does not change global or
other sessions' settings. Existing running turns retain their selected model.

New clients confirm creation, configure both choices once, confirm completion,
then send the first message. A confirmed session is retained if later work fails;
clients do not recreate it or automatically replay an uncertain message. Hosts
omit `projects.create`, like `sessions.configure`, from all legacy snapshot/event
command projections and use actor-scoped `commands.get` for command completion.
No new required event kind is introduced. M0 remains unchanged.

## Visible thinking and complete-text paging

Package `0.0.0-v1.6` adds optional `message.thinking.versioned.v1`. After negotiation,
clients add `thinkingVersion:2` to thinking-enabled `events.open` and `sessions.history`,
and to `messages.thinking`. Version 2 adds a bounded, opaque `generation` identifier to
every thinking block and page. It stays stable while text is appended or the same
authorization is resynchronized, and changes after a response reset or Host restart,
even if the new text repeats the old prefix. Clients bind accumulated pages and
in-flight reads to that generation. A replacement generation clears old pages before
rendering its preview; a normal same-generation refresh retains reading state.
Without this explicit version, the original v1.5 shape below remains unchanged.
The version is fixed per subscription, not per device. Generation carries no extra
authorization and does not expose a provider response identifier or hidden context.

Package `0.0.0-v1.5` adds the optional `message.thinking.v1` capability without
changing `cowork.remote/1`. The Host returns it only when requested. It is a
display feature, not a new device permission: existing `read` permission and
current project/session authorization apply to every snapshot, history page,
thinking page and event. Clients omit all thinking opt-ins and do not call
`messages.thinking` when the Host does not return this capability.

After negotiation, `events.open({filter,includeThinking:true})` opts that specific
subscription into thinking blocks. The choice is immutable and bound to the
subscription and its cursor; it must not be stored as a device-wide switch.
`sessions.snapshot` inherits it from `subscriptionId`, and its schema permits no
separate override. Reconnection and replacement subscriptions preserve the
explicit choice. `sessions.history({sessionId,includeThinking:true,...})` opts
only that history request into the same projection. Omission or `false` on either
request retains the original response and event shapes with no thinking block.
The Host may serve simultaneous old and new subscriptions for the same device.
It must never send the new block to a legacy subscription: strict old validators
reject unknown blocks. Schema validation alone cannot establish request/response
opt-in consistency; both consumers enforce negotiation and matching projections.

The new assistant message block is
`{type:"thinking",text,status:"running"|"completed",truncated:boolean}`.
It contains only the public `Message.thinking` text already visible in the desktop
conversation. `running` follows the desktop thinking phase; `completed` means
that thinking is no longer streaming, not that the whole task succeeded. A
transition to answer text, a retry reset or a finished response replaces the
whole message at a newer revision. A reset removes the discarded thinking text;
clients must not append a replacement message to the previous attempt's text.
An empty block must not invent reasoning when the model supplied none.

Credential redaction applies before projection and paging, as it does to visible
answer text. Do not derive this field from hidden/system messages, system
prompts, context, tool raw inputs, `modelContent`, provider replay signatures,
encrypted reasoning or opaque redacted-thinking blocks. Displaying public
thinking does not authorize any additional model request, filesystem access or
execution. Clients may collapse it by default and expand it separately from the
answer; copying the answer need not copy its thinking.

Each block and full-text page is limited to 8192 Unicode characters. The Host
additionally limits a page to 8192 UTF-8 text bytes and bounds its serialized JSON;
thinking blocks share the existing 32768-byte event budget with text, tools,
assets and envelope overhead. Truncate valid Unicode safely and mark partial
blocks with `truncated:true`. Character counts alone do not prove that an event
fits. Do not repeatedly produce oversized events that force resynchronization.

For a truncated preview, `messages.thinking` reads the complete visible text in
bounded pages. The first request omits `cursor` and starts from the beginning;
its pages replace, rather than duplicate, the inline preview. The Host verifies
the requested message belongs to the authorized session and is a visible
assistant message. Unknown, hidden or system messages are not readable through
this method. Each opaque cursor is bound to its authenticated actor, grant
revision, session, message, text generation and current redaction projection.
The client cannot request offsets, local paths or another actor's data. The Host
reauthorizes after asynchronous work before returning any page.

Appending text to the same thinking generation may continue from a prior cursor.
Resetting or replacing the already-read prefix invalidates it with
`cursor-invalid`; clients clear the old concatenated text and restart from the
beginning. Grant changes, scope removal, revocation and unavailable messages
must fail under the existing authorization rules instead of preserving access
through a cursor. Clients also discard in-flight pages after changing their
host, session, message, grant or thinking generation.

A completed final page has `nextCursor:null`. A running response may return a
cursor at the currently available end so later appended text can be read. An
empty running page is not completion: retain its cursor and await new message
activity or use bounded retry rather than a tight pagination loop. Full-text
paging introduces no required event kind or write command. The existing
`message.updated` event, snapshot and history revision rules still apply.

## Write parameters

- `sessions.create`: `{projectId,executionMode:"local"|"worktree",title?}` or the negotiated ordinary branch above.
- `projects.create`: `{name,initGit?}`; requires negotiated `projects.create.v1`.
- `sessions.configure`: `{sessionId,expectedRevision,permissionMode:PermissionMode|null,modelChoiceId?:Id|null}`.
  Requires negotiated `session.execution.v1`; the session must be idle.
- `messages.send`: `{sessionId,mode:"start"|"queue"|"steer",expectedTurnId:string|null,text,assetIds:string[]}`.
  Start requires null; queue/steer require an actual turn ID. No implicit auto mode.
- `turns.abort`: `{sessionId,expectedTurnId}`.
- `queues.resume`: `{sessionId,expectedTurnId:null,expectedQueueRevision,queueEntryIds:string[]}`.
- `queues.cancel`: `{sessionId,expectedQueueRevision,queueEntryIds:string[]}`.
- `approvals.respond`: `{sessionId,expectedTurnId,requestId,requestVersion,decision:"allow-once"|"deny"}`.
- `questions.answer`: `{sessionId,expectedTurnId,requestId,requestVersion,answer:{optionIndex:number}|{text:string}}`.
- `assets.upload`: `{sessionId,name,mediaType,sizeBytes,sha256}`.
  A durable upload command preallocates `uploadId`; its terminal result includes
  `upload:UploadDescriptor`. Stream bytes only after that command succeeds.

`CommandReceipt` is `{commandId,method,state:"accepted",acceptedAt,sessionId?,turnId?,queueEntryId?,uploadId?,projectId?}`.
`CommandView` is `{receipt,status:"accepted"|"dispatching"|"terminal",outcome?,result?,error?,recoveryRequired:boolean,revision}`.
Terminal outcomes are `succeeded|failed|cancelled|uncertain`. Result is a bounded
object with optional `sessionId,turnId,queueEntryId,queueEntryIds,uploadId,assetId,
stopRequested,upload,projectId`. No arbitrary result object is exposed.

## Complete projected entities

All revisions and event sequence numbers are canonical unsigned decimal strings.
All time strings are UTC RFC3339; identifiers contain only ASCII alphanumerics,
underscore and hyphen. DTOs do not expose structured Host filesystem fields such as
`cwd` or `sourceRepo`, provider credentials or system prompts. Visible text from an
authorized conversation may contain paths already present in messages, titles,
tool summaries, queued inputs and permission/question text; these paths are preserved
so instructions and answers remain meaningful. Credential redaction still applies.
Text containing a path does not grant filesystem access, and resource endpoints
continue to accept scoped opaque identifiers rather than arbitrary paths. The optional
execution view contains only the bounded model label and session permission modes.

- `ProjectView`: `{projectId,name,executionModes:("local"|"worktree")[],unavailableReason?}`;
  empty modes and their reason are available only through the negotiated opt-in above.
- `SessionSummary`: `{sessionId,projectId,title,revision,status,updatedAt}`;
  status is `idle|running|interrupted|failed|completed|deleted`.
- `SessionSnapshot`: `{session,messages,activeTurn,queue,pendingApprovals,
  pendingQuestions,commandRefs,historyCursor}`. `activeTurn` and `historyCursor`
  may be null; `commandRefs` is a bounded array of full `CommandView` values.
- `MessageView`: `{messageId,role:"user"|"assistant",blocks,revision,truncated}`.
  Blocks are `{type:"text",text}`, `{type:"tool",tool:ToolActivityView}`, or
  `{type:"asset",asset:AssetRef}`; opted-in assistant messages may also contain
  the bounded `thinking` block described above.
- `ToolActivityView`: `{toolCallId,displayName,summary,summaryTruncated,status,assets}`;
  status is `running|succeeded|failed|cancelled`.
- `TurnView`: `{turnId,status,revision}`;
  status is `running|stopping|interrupted|succeeded|failed|cancelled`.
- `QueueView`: `{revision,paused,entries:QueueEntryView[]}`.
- `QueueEntryView`: `{queueEntryId,text,textTruncated,assetIds,createdAt,state}`;
  state is `pending|paused|started|cancelled`.
- `ApprovalView`: `{requestId,turnId,requestVersion,status,displayName,summary,
  summaryTruncated,allowedDecisions:("allow-once"|"deny")[],localOnly}`;
  status is `pending|resolved`.
- `QuestionView`: `{requestId,turnId,requestVersion,status,title,prompt,
  promptTruncated,kind:"choice"|"approval",options:string[],allowText,async,
  localOnly,recommendedOptionIndex?,autoPickAt?}`; status is `pending|resolved`.
- `AssetRef`: `{assetId,sessionId,name,mediaType,sizeBytes,sha256,canRead,revision}`.
- `UploadDescriptor`: `{uploadId,sessionId,sizeBytes,sha256,expiresAt,chunkBytes}`.

## SSE and asset streams

`GET /remote/v1/events?subscriptionId=...&after=...` always authenticates. Cursors
and subscription IDs do not authorize access. SSE records use `event: remote-event`,
`id: <cursor>` and JSON `data`. Client commits the cursor only after applying data.

An event is `{type,version:1,required:true,hostEpoch,seq,grantRevision,sessionId?,payload}`.
State events replace complete entities; no text deltas are used:

- `session.updated`: `{session:SessionSummary}`.
- `message.updated`: `{message:MessageView}` with required `sessionId`.
- `turn.updated`: `{activeTurn:TurnView|null,revision}` with required `sessionId`.
- `queue.updated`: `{queue:QueueView}` with required `sessionId`.
- `approval.updated`: `{approvals:ApprovalView[],revision}` with required `sessionId`.
- `question.updated`: `{questions:QuestionView[],revision}` with required `sessionId`.
- `command.updated`: `{command:CommandView}` with optional `sessionId`.
- `asset.updated`: `{asset:AssetRef}` with required `sessionId`.
- `stream.resync-required`, `auth.expired`, `access.changed`, `server.stopping`:
  `{code:<bounded Remote error code>}`. These stop application/reconnect as appropriate.

Optional diagnostics are `{type:"diagnostic",version:1,required:false,...,
 payload:{message:string}}`; they never change authoritative state. Unknown required
messages stop projection and require compatibility negotiation.

`PUT /remote/v1/uploads/{uploadId}` is authenticated binary content. Length and
SHA-256 must match the upload descriptor; success is HTTP 200 `{asset:AssetRef}`.
The same completed upload may be retried with identical content. A different body
fails; a response loss must not create another asset. `GET
/remote/v1/assets/{assetId}/content` authenticates each read and forces download
for active content. No content endpoint accepts a filesystem path or arbitrary URL.

## Private Bridge v1

Server selection is `COWORK_BRIDGE_VERSION=cowork.bridge/1`; absent means M0.
Handshake and bootstrap keep M0 fields but carry `bridgeVersion:"cowork.bridge/1"`;
bootstrap `maxRequestBytes` is 65536. No external client supplies actor or grants.

Authenticated request operations:

- `rpc.call`: payload is the exact Remote v1 request; result is the complete
  Remote response envelope (query, receipt or bounded error).
- `events.poll`: `{subscriptionId,after,maxEvents}` →
  `{events:[{cursor,event}],closed:boolean,error?:RemoteError}`. `maxEvents` is
  1..16. Poll bytes stay below 524288. Host reauthorizes every poll, checks cursor
  continuity and returns an empty array for keepalive. Server may wait briefly
  between empty polls; it never advances after beyond the last delivered record.
- `assets.upload.chunk`: `{uploadId,offset,dataBase64,eof}` →
  `{uploadId,offset,complete:boolean,asset?:AssetRef}`. Offset is the next byte;
  final validated content returns complete with asset. Each chunk is reauthorized.
- `assets.read.chunk`: `{assetId,offset,maxBytes}` →
  `{asset:AssetRef,offset,dataBase64,eof}`. Offset echoes the first returned byte;
  maxBytes is 1..16384. Each chunk is reauthorized.

Pairing operations retain their M0 payload/result schemas through explicit refs.
Other operations are denied. Binary content is bounded base64 inside these private
chunk frames only; the public content stream remains binary.
EOF, invalid frame, revoked credentials or transport cancellation cannot silently
continue an existing authorized stream. Durable write recovery is by command ID.

## Opt-in activity metadata and attention summaries (package v1.7)

The wire identifiers remain `cowork.remote/1` and `cowork.bridge/1`. A client requests
`message.activity.v1` in hello and only sends `includeActivity: true` on
`events.open` or `sessions.history` after the Host echoes it. Omission or false
preserves the legacy message/turn shape. Subscription cursors bind this choice;
snapshots inherit it and cannot override it. Message and turn SSE updates use the
same selection. No new device permission is introduced.

`message.activity` contains Host Unix-millisecond `createdAt`, and only existing
local `turnId`, `phase`, `streaming`, user-only `steer: true`, and `turnTiming`.
`turnTiming` is the exact persisted whole-turn `{ startedAt, endedAt, durationMs }`.
The duration uses the Host's monotonic clock; wall-clock reversal is valid and
clients must not replace it with `endedAt - startedAt`. Legacy messages without a
recorded duration do not gain an estimated completed duration. Hidden/system
messages and provider/internal request metadata remain excluded.

A live `activeTurn.activity` is `{ startedAt, observedAt, elapsedMs }`, where the
start is the originating user's timestamp and the Host samples its current wall
clock with `elapsedMs = max(0, observedAt - startedAt)`. Clients may advance this
sample using a local monotonic receipt baseline, never their own wall clock minus
the Host timestamp. Reconnect obtains a fresh authoritative sample; completion
uses persisted `turnTiming.durationMs`.

`session.attention.v1` advertises the read-only `sessions.attention` method.
Parameters are optional `cursor` and `limit` (1–50); result is
`{ hostEpoch, grantRevision, items, nextCursor }`, with each item containing
`session`, `pendingApprovals` and `pendingQuestions` in their existing safe shapes.
Only currently readable sessions with pending interactions appear. This is not a
new grant, cannot discover arbitrary host paths, and does not make local-only
interactions remotely actionable. Responses are capped by the normal byte budget.
Cursors bind actor, grant revision, Host instance and the pending-request identity;
a changed pending set requires restarting pagination after `cursor-invalid`.
