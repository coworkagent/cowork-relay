# Cowork Protocol

Candidate **0.0.6-relay.1** adds the independent
[encrypted relay transport](relay/V1-CONTRACT.md) and `@cowork/protocol/relay/control`
schema. Relay authentication does not replace paired-host TLS or Remote grants.
This candidate has not been published; existing Remote and Bridge surfaces remain unchanged.

Version 0.0.5 supports negotiated adjacent older-history pages: clients can show recent messages first and request earlier content as needed. Existing clients keep their original paging behavior.

Optional [paired-host LAN discovery](remote/DISCOVERY.md) lets clients find
an existing computer after its address changes. Endpoint proofs are signed
by the paired host identity; discovery never grants access or replaces TLS.

[简体中文](README.zh-CN.md)

Language-neutral JSON Schemas and conformance fixtures for Cowork clients and hosts. The public Remote
surface and private Host Bridge are separately exported and versioned. This repository does not execute
agents, store sessions, authenticate devices or implement network transports.

**Version 0.0.5** adds signed LAN endpoint discovery and adjacent older-history
paging. It retains bilingual product display metadata, original conversation
content and legacy projection fallbacks.
M0 remains available unchanged. Separate v1 schemas
now describe session commands, durable receipts, approvals, questions, bounded snapshots/history,
authenticated event recovery and asset streaming. A schema does not imply that every consuming app
has shipped the feature. Browser credentials remain outside this implementation. The package is
private and `UNLICENSED`. Versioned archives are distributed through GitHub releases;
this package is not published to the public npm registry.

## Contract surfaces

| Export | Contract |
| --- | --- |
| `@cowork/protocol/remote` | `remote/m0.schema.json`; Remote `cowork.remote/1-m0`, invitation `cowork.pairing/1-m0` |
| `@cowork/protocol/bridge` | `bridge/m0.schema.json`; private `cowork.bridge/1-m0` |
| `@cowork/protocol/remote/constants` | Schema-derived protocol identifiers, endpoint paths, errors and request bound |
| `@cowork/protocol/bridge/constants` | Schema-derived Bridge identifier, frame bound and header length |
| `@cowork/protocol/remote/v1` | Remote `cowork.remote/1` schema and generated TypeScript DTO declarations |
| `@cowork/protocol/remote/v1/constants` | Schema-derived v1 limits, paths, errors and method metadata |
| `@cowork/protocol/bridge/v1` | Private Bridge `cowork.bridge/1` schema |
| `@cowork/protocol/bridge/v1/constants` | Schema-derived v1 private framing constants |

Schemas use JSON Schema draft 2020-12. Their `.invalid` `$id` values identify schemas; they are not
network endpoints. Register the local schema documents with a validator instead of fetching them.
Remote has no dependency on Bridge. Bridge references Remote DTOs, so register Remote before Bridge.
Native implementations can consume the same JSON without executing JavaScript. The small JavaScript
constant adapters contain no separate protocol definitions or runtime dependencies.

Named Remote `$defs` are `pairingInvitation`, `pairingCandidateRequest`, `pairingCandidateResponse`,
`pairingClaimRequest`, `pairingClaimResponse`, `helloRequest`, `helloResponse`, `error`,
`pairingErrorResponse` and `rpcErrorResponse`. Validate against the expected definition, not merely the
union at the document root. Bridge definitions are `hello`, `bootstrap`, `ready`, `request`, `response`
and `frame`.

## M0 exchange

1. The owner opens pairing on the computer. Its invitation contains the HTTPS origin, installation
   identity, leaf certificate SHA-256 digest, host-scoped CA certificate in DER base64, expiring pairing
   ID and one-time 256-bit invitation secret. The certificate and fingerprint are public trust material;
   the invitation secret is sensitive. No long-lived device credential belongs in the invitation.
2. The native client validates the chain against that host's scoped CA using platform TLS, including
   hostname and validity checks, and verifies the leaf pin before transmitting a secret. Reading the
   invitation or matching a fingerprint alone does not establish authenticated TLS. A browser cannot
   use this contract to bypass certificate validation.
3. `POST /remote/v1/pairing/candidates` registers the native candidate. The response provides a separate
   candidate secret and six-digit code for the owner to compare on both devices. The code is not a
   credential. Device approval exists only on the computer, outside Remote and Bridge method lists.
4. `POST /remote/v1/pairing/claim` proves possession of the candidate secret. Only the approved candidate
   can receive a native credential. Host logic must enforce expiry, candidate limits, one-time approval,
   and same-device claim recovery without creating a second device registration.
5. `POST /remote/v1/rpc` accepts only `connection.hello` in M0 and requires `Authorization: Bearer` with
   the native credential. Hello returns the authenticated device, installation, authorization revision
   and limits. Its negotiated capability list is empty: M0 must not imply session execution support.

Credentials never appear in URLs. The Host owns authorization, expiry and revocation and derives the
actor from the verified credential, not request fields. Both a Gateway and Host validate their boundary
inputs. Pairing errors use `{ error }`; RPC errors with a valid correlation ID use `{ traceId, error }`.
Transport rejection before a valid request can be identified may use `{ error }`. Error codes are in
the schema; raw exceptions and filesystem paths are not error fields.

## Private Bridge

The original Node M0 adapter uses inherited duplex file descriptor 3; Rust uses inherited stdin/stdout
pipes with stdout reserved for frames. Each M0 frame has a four-byte unsigned big-endian byte length,
followed by that many UTF-8 JSON bytes. Reject zero length, malformed UTF-8, and lengths above 65,536
before buffering a payload. HTTP request bodies are bounded to 16,384 bytes. JSON Schema character
limits do not replace these transport byte limits.

The child sends `hello` with the launch nonce; the Host returns `bootstrap` with the same nonce,
selected IPv4 listener and TLS material. The child validates the bootstrap before listening and sends
`ready`. Nonces are passed through the controlled process environment, never command-line arguments.
TLS private material travels only on this private channel and must never be logged. Parent pipe EOF
closes the listener and child process. This process boundary is not an operating-system sandbox.

Requests permit only `pairing.candidate`, `pairing.claim` and `connection.hello`. `authRef` is required
for hello and forbidden for pairing; it is an opaque credential the Host verifies. Hello's payload and
result are complete Remote envelopes. Responses correlate by `bridgeRequestId`; the caller must also
validate the result against its outstanding operation's expected definition. No generic event or local
administration frame exists in M0. The Host revokes devices locally; later authentication must fail.

## Validation and maintenance

```sh
npm ci
npm run check
npm pack --dry-run
```

Checks validate every schema and fixture with strict Ajv 2020-12 and `ajv-formats`, reject unknown
fields, and ensure validation does not mutate input. JavaScript adapters receive syntax and runtime
checks. V1 DTO declarations and method mappings are generated from the canonical schema;
`npm run generate:check` detects drift. JSON Schema bounds remain mandatory runtime checks even
when TypeScript represents an array without a fixed tuple bound. Development dependencies are
locked and not required by language-neutral consumers.

Fixture envelopes contain a named `schema`, a `reason` and a `value`; validate the `value`. All secrets,
addresses, certificate bytes and keys in fixtures are synthetic. The PEM/DER fixtures intentionally
test structure only and are not valid cryptographic certificates. Shape validation cannot verify
randomness, TLS trust, token validity, current time, approval, rate limiting or process lifecycle;
consumers must test these behaviors separately.

Change schemas and fixtures together. Wire-breaking M0 changes require coordinated consumer updates;
do not treat this prerelease as a frozen v1. There are no sibling-checkout or desktop-source dependencies.
For local integration, pack this repository and explicitly install that archive in the consumer, then
record the tested commit and archive digest. No npm scope ownership or release channel is assumed.

Validator implementation references: [Ajv JSON Schema support](https://ajv.js.org/json-schema.html) and
[format validation](https://ajv.js.org/guide/formats.html).

## v1 usage

Optional capability negotiation exposes whether the computer currently permits remote execution and
why an authorized project is unavailable. Compatible clients can explain blocked actions before
submission without receiving local paths or raw settings. Older clients retain the previous hello and
usable-project response shapes; newer clients can connect to older hosts with policy status unknown.
The [v1 contract guide](remote/V1-CONTRACT.md#optional-policy-and-project-availability-negotiation)
defines the opt-in fields and compatibility rules. These projections do not replace authorization.

An optional session execution capability lets authorized clients read the current model and
permission mode, or change the mode for one idle session without changing the computer default.
Changes use durable commands and revision checks; unsupported Hosts retain their existing behavior.

The [v1 contract guide](remote/V1-CONTRACT.md) specifies all twenty-eight methods, entity projections,
receipt states, SSE cursor recovery and private asset chunks. Read/control success is HTTP 200;
durable write acceptance is HTTP 202 and is distinct from command or Agent completion. Never
automatically resend an uncertain write using a new command ID. Apply an SSE event before advancing
its cursor; epoch, grant or scope changes require a new subscription and snapshot.

```ts
import type { V1Request, V1Response, SessionSnapshot, V1MethodMap } from "@cowork/protocol/remote/v1";
```

V1 Bridge includes explicit references to the unchanged M0 pairing definitions. Validators register
Remote M0, Remote v1 and Bridge v1 locally. V1 uses 64 KiB requests, 512 KiB responses, 32 KiB events,
1 MiB private frames, 16 KiB asset chunks and 10 MiB assets. Serialized byte bounds supplement schema
character limits. Native transports must preserve platform TLS validation and scoped trust.

Optional creation and model capabilities support ordinary conversations in Host-managed folders,
new managed projects, and per-session model choices alongside permission modes. New creation rights
must be granted explicitly on the computer; existing project control never grants arbitrary filesystem
access. Model catalogs contain opaque choices and display labels, without connection secrets. These
extensions preserve older response shapes through explicit negotiation and request opt-in. See the
[implementation contract](remote/V1-CONTRACT.md) for ownership, idempotency and compatibility rules.

Package `0.0.0-v1.5` adds optional `message.thinking.v1`. Explicit subscription and history opt-ins
show the same public thinking text already visible on the computer, with a collapsible state and a
bounded preview. The read-only `messages.thinking` method pages through the complete visible text.
Existing read permissions and credential redaction still apply; hidden context, system prompts,
tool raw inputs and encrypted reasoning are excluded. Old clients keep their original messages and
event shapes. Schema support alone does not establish that consuming applications have shipped this
feature. See [visible thinking and paging](remote/V1-CONTRACT.md#visible-thinking-and-complete-text-paging).

Package `0.0.0-v1.6` adds opt-in thinking generation identifiers. They let a client retain reading
state during ordinary refreshes while discarding an earlier attempt after a response restarts.
Older thinking subscriptions keep their original response shape.

Package v1.7 adds explicitly negotiated `message.activity.v1` timing/grouping
metadata and the authorized, paged `sessions.attention` read under
`session.attention.v1`. Legacy subscriptions and history keep their prior shape;
see `remote/V1-CONTRACT.md` for Host-clock and completed-duration semantics.

Workspace reading is available through an explicitly negotiated extension and a
separate device grant. Clients can browse directories, read bounded source chunks,
and inspect scoped changes and diffs without gaining filesystem write access.
Existing device grants stay unchanged. See the [workspace contract](remote/V1-CONTRACT.md#workspace-reading-extension).
