import schema from './v1.schema.json' with { type: 'json' };
import remote from '../remote/v1.schema.json' with { type: 'json' };

export const BRIDGE_PROTOCOL = schema.$defs.bridgeProtocol.const;
export const MAX_BRIDGE_FRAME_BYTES = remote.$defs.maxBridgeFrameBytes.const;
export const FRAME_HEADER_BYTES = schema.$defs.frameHeaderBytes.const;
