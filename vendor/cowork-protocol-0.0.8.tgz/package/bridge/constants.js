import schema from './m0.schema.json' with { type: 'json' };
import remoteSchema from '../remote/m0.schema.json' with { type: 'json' };

export const BRIDGE_PROTOCOL = schema.$defs.bridgeProtocol.const;
export const MAX_BRIDGE_FRAME_BYTES = remoteSchema.$defs.maxBridgeFrameBytes.const;
export const FRAME_HEADER_BYTES = schema.$defs.frameHeaderBytes.const;
