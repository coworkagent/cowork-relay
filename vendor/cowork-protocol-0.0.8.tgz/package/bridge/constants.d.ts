export declare const BRIDGE_PROTOCOL: string;
export declare const MAX_BRIDGE_FRAME_BYTES: number;
export declare const FRAME_HEADER_BYTES: number;
