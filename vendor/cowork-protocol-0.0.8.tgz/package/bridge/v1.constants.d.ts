/* 从 Bridge v1 schema 自动生成，请勿手工修改。 */
export const BRIDGE_PROTOCOL: "cowork.bridge/1";
export const MAX_BRIDGE_FRAME_BYTES: 1048576;
export const FRAME_HEADER_BYTES: 4;
