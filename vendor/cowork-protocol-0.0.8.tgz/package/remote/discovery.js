export const DISCOVERY_SERVICE_TYPE = '_cowork._tcp';
export const DISCOVERY_PROTOCOL = 'cowork.endpoint/1';
export const DISCOVERY_LIFETIME_SECONDS = 120;
const fields = ['v', 'id', 'ip', 'port', 'fp', 'iat', 'exp', 'sig'];
const invalid = () => { throw new Error('discovery-invalid'); };

/** TXT 仅提供候选；调用者必须用已配对的 CA 验签，再验证 TLS 与 hello 身份。 */
export function parseDiscoveryAdvertisement(value, expectedHostId, nowMs = Date.now()) {
  if (!value || typeof value !== 'object' || Array.isArray(value)
    || Object.keys(value).length !== fields.length || fields.some(key => typeof value[key] !== 'string' || value[key].length > 200)) return invalid();
  const record = Object.fromEntries(fields.map(key => [key, value[key]]));
  if (record.v !== '1' || !/^[A-Za-z0-9_-]{1,128}$/.test(record.id) || record.id !== expectedHostId
    || !/^[1-9][0-9]{0,4}$/.test(record.port) || Number(record.port) > 65535
    || !/^[a-f0-9]{64}$/.test(record.fp)
    || !/^[1-9][0-9]{0,11}$/.test(record.iat) || !/^[1-9][0-9]{0,11}$/.test(record.exp)
    || !/^(?:[A-Za-z0-9+/]{4}){16,25}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(record.sig)) return invalid();
  const parts = record.ip.split('.');
  if (parts.length !== 4 || parts.some(part => !/^(0|[1-9][0-9]{0,2})$/.test(part) || Number(part) > 255)) return invalid();
  const [a, b] = parts.map(Number);
  if (!(a === 10 || a === 172 && b >= 16 && b <= 31 || a === 192 && b === 168)) return invalid();
  const now = Math.floor(nowMs / 1000), issued = Number(record.iat), expires = Number(record.exp);
  if (!Number.isFinite(now) || issued > now + 30 || expires <= now || expires <= issued || expires - issued > DISCOVERY_LIFETIME_SECONDS) return invalid();
  return { record, hostId: record.id, httpsOrigin: `https://${record.ip}:${record.port}`, certificateSha256: record.fp,
    expiresAt: expires * 1000, signingPayload: discoverySigningPayload(record) };
}

/** ASCII 字段和固定行序避免跨语言 JSON 序列化差异；签名本身不参与待签名内容。 */
export function discoverySigningPayload(record) {
  return [DISCOVERY_PROTOCOL, record.v, record.id, record.ip, record.port, record.fp, record.iat, record.exp, ''].join('\n');
}
