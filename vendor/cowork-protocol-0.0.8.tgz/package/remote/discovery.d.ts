export const DISCOVERY_SERVICE_TYPE: '_cowork._tcp';
export const DISCOVERY_PROTOCOL: 'cowork.endpoint/1';
export const DISCOVERY_LIFETIME_SECONDS: 120;
export interface DiscoveryAdvertisement {
  v: '1'; id: string; ip: string; port: string; fp: string;
  iat: string; exp: string; sig: string;
}
export interface DiscoveryCandidate {
  record: DiscoveryAdvertisement; hostId: string; httpsOrigin: string;
  certificateSha256: string; expiresAt: number; signingPayload: string;
}
export function parseDiscoveryAdvertisement(value: unknown, expectedHostId: string, nowMs?: number): DiscoveryCandidate;
export function discoverySigningPayload(record: Omit<DiscoveryAdvertisement, 'sig'>): string;
