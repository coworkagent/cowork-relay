import schema from './m0.schema.json' with { type: 'json' };

export const REMOTE_PROTOCOL = schema.$defs.remoteProtocol.const;
export const PAIRING_PROTOCOL = schema.$defs.pairingProtocol.const;
export const MAX_REQUEST_BYTES = schema.$defs.maxRequestBytes.const;
export const PATHS = Object.freeze(Object.fromEntries(
  Object.entries(schema.$defs.paths.properties).map(([key, value]) => [key, value.const]),
));
export const ERROR_CODES = Object.freeze([...schema.$defs.error.properties.code.enum]);
