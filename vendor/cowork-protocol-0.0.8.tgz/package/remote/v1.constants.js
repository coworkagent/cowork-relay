import schema from './v1.schema.json' with { type: 'json' };

export const REMOTE_PROTOCOL = schema.$defs.remoteProtocol.const;
export const MAX_REQUEST_BYTES = schema.$defs.maxRequestBytes.const;
export const MAX_RESPONSE_BYTES = schema.$defs.maxResponseBytes.const;
export const MAX_BRIDGE_FRAME_BYTES = schema.$defs.maxBridgeFrameBytes.const;
export const MAX_EVENT_BYTES = schema.$defs.maxEventBytes.const;
export const MAX_ASSET_BYTES = schema.$defs.maxAssetBytes.const;
export const MAX_ASSET_CHUNK_BYTES = schema.$defs.maxAssetChunkBytes.const;
export const PATHS = Object.freeze(Object.fromEntries(Object.entries(schema.$defs.paths.properties).map(([name, value]) => [name, value.const])));
export const METHODS = Object.freeze(Object.fromEntries(Object.entries(schema.$defs.methods.const).map(([name, value]) => [name, Object.freeze({ ...value })])));
export const ERROR_CODES = Object.freeze([...schema.$defs.error.properties.code.enum]);
