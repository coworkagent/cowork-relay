# Paired host endpoint discovery

Optional LAN discovery uses DNS-SD `_cowork._tcp` in the local domain.
Service instance names and DNS addresses are untrusted display/routing
metadata, never pairing authority. A fresh TXT proof authorizes a local
IPv4 endpoint and leaf fingerprint under the existing paired host CA.
No pairing secrets, credentials, user names or conversation data appear.

All TXT values are ASCII strings. Exactly these fields are defined:

| Field | Value |
| --- | --- |
| v | `1` |
| id | Existing host ID, 1–128 letters, digits, underscores or hyphens |
| ip | Canonical RFC 1918 IPv4 address |
| port | Canonical decimal TCP port, 1–65535 |
| fp | Lowercase SHA-256 of the current leaf DER certificate |
| iat | Issued Unix timestamp in seconds |
| exp | Expiry Unix timestamp, after iat and at most 120 seconds later |
| sig | Canonical base64 of DER ECDSA P-256/SHA-256 signature |

Sign the ASCII `cowork.endpoint/1`, v, id, ip, port, fp, iat and exp,
each followed by one LF, using the existing host CA private key. The
shared `discoverySigningPayload` implementation defines exact bytes.
Each TXT item must fit within 255 bytes. Receivers reject a proof issued
over 30 seconds into the future or expired at their current time.

Before sending a credential, verify the signature with the public key
from the already-paired CA certificate. Never accept a root supplied by
discovery. Then use ordinary scoped TLS validation, IP SAN verification
and the advertised exact leaf fingerprint. A successful authenticated
hello must match the saved host and device before persisting the endpoint.
Endpoint updates preserve grants, credentials, aliases and local drafts.
Failed, stale or mismatched candidates cannot replace the saved endpoint.
Disconnecting, forgetting or changing hosts cancels pending migrations.
Commands with uncertain outcomes are queried by their original IDs,
never replayed as part of discovery or reconnection.

Publish only while the explicit remote service is running. Renew before
expiry, withdraw when stopped, and publish the new address after rebinding.
Discovery failure must not prevent manual connection to a saved endpoint.
