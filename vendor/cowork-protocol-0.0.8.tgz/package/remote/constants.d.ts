export declare const REMOTE_PROTOCOL: string;
export declare const PAIRING_PROTOCOL: string;
export declare const MAX_REQUEST_BYTES: number;
export declare const PATHS: Readonly<{
  pairingCandidates: string;
  pairingClaim: string;
  rpc: string;
}>;
export declare const ERROR_CODES: readonly string[];
