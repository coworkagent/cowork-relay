import schema from './endpoint.schema.json' with { type: 'json' };
export const RELAY_ENDPOINT_PROTOCOL = schema.$defs.protocol.const;
export const RELAY_PAIRING_PROTOCOL = schema.$defs.pairingProtocol.const;
export const RELAY_ENDPOINT_PATH = schema.$defs.path.const;
export const RELAY_ENDPOINT_LIFETIME_SECONDS = schema.$defs.lifetimeSeconds.const;
export const RELAY_ENDPOINT_MAX_BYTES = schema.$defs.maxResponseBytes.const;
const fields = Object.keys(schema.$defs.endpoint.properties);
const unsignedFields = fields.filter(key => key !== 'signature');
const invalid = () => { throw new Error('relay-endpoint-invalid'); };
const exact = (value, keys) => value !== null && typeof value === 'object' && !Array.isArray(value)
  && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const match = (value, definition) => typeof value === 'string' && value.length >= (definition.minLength ?? 0) && value.length <= (definition.maxLength ?? 300)
  && new RegExp(definition.pattern).test(value);

function canonicalOrigin(value) {
  if (!match(value, schema.$defs.relayOrigin)) return false;
  try { const url = new URL(value); return url.protocol === 'https:' && !url.hostname.endsWith('.') && url.port !== '0'
    && (url.origin === value || !url.port && `${url.origin}:443` === value); }
  catch { return false; }
}
function read(value, signed) {
  if (!exact(value, signed ? fields : unsignedFields) || value.protocol !== RELAY_ENDPOINT_PROTOCOL
    || !match(value.hostId, schema.$defs.hostId) || !match(value.relayHostId, schema.$defs.relayHostId)
    || !canonicalOrigin(value.relayOrigin) || value.httpsOrigin !== `https://${value.relayHostId}.cowork.invalid`
    || !match(value.certificateSha256, schema.$defs.certificateSha256)
    || ![value.issuedAt, value.expiresAt].every(time => Number.isSafeInteger(time) && time >= 1 && time <= schema.$defs.timestamp.maximum)
    || value.expiresAt <= value.issuedAt || value.expiresAt - value.issuedAt > RELAY_ENDPOINT_LIFETIME_SECONDS
    || signed && !match(value.signature, schema.$defs.signature)) return invalid();
  return Object.fromEntries((signed ? fields : unsignedFields).map(key => [key, value[key]]));
}

/** 固定 ASCII 行序和域分离；不依赖 JSON 键顺序，也不把签名本身纳入载荷。 */
export function relayEndpointSigningPayload(value) {
  const record = read(value, false);
  return [...unsignedFields.map(key => String(record[key])), ''].join('\n');
}

/** 只解析候选。调用者还必须用原配对 CA 验签、验证两层 TLS，再以 hello 确认身份。 */
export function parseRelayEndpoint(value, expected, nowMs = Date.now()) {
  const record = read(value, true);
  if (!expected || record.hostId !== expected.hostId || record.relayOrigin !== expected.relayOrigin
    || record.relayHostId !== expected.relayHostId) return invalid();
  const now = Math.floor(nowMs / 1000);
  if (!Number.isFinite(now) || record.issuedAt > now + schema.$defs.clockSkewSeconds.const || record.expiresAt <= now) return invalid();
  const { signature: _signature, ...unsigned } = record;
  return { record, hostId: record.hostId, httpsOrigin: record.httpsOrigin, certificateSha256: record.certificateSha256,
    expiresAt: record.expiresAt * 1000, signingPayload: relayEndpointSigningPayload(unsigned) };
}

/** 二维码只携带短期邀请和公开 Host 信任，外层登记必须事先独立导入并精确匹配。 */
export function parseRelayInvitation(value, expectedRelay, nowMs = Date.now()) {
  if (!exact(value, Object.keys(schema.$defs.invitation.properties)) || value.protocol !== RELAY_PAIRING_PROTOCOL
    || !match(value.trustAnchorDerBase64, schema.$defs.invitation.properties.trustAnchorDerBase64)
    || !match(value.pairingId, schema.$defs.invitation.properties.pairingId)
    || !match(value.invitationSecret, schema.$defs.invitation.properties.invitationSecret)
    || typeof value.expiresAt !== 'string' || !Number.isFinite(Date.parse(value.expiresAt))
    || new Date(value.expiresAt).toISOString() !== value.expiresAt) throw new Error('relay-invitation-invalid');
  const endpoint = parseRelayEndpoint(value.endpoint, { ...expectedRelay, hostId: value.endpoint?.hostId }, nowMs);
  const expiresAt = Date.parse(value.expiresAt);
  if (expiresAt <= nowMs || expiresAt > endpoint.expiresAt || expiresAt - nowMs > RELAY_ENDPOINT_LIFETIME_SECONDS * 1000)
    throw new Error('relay-invitation-expired');
  return { ...value, endpoint: endpoint.record, signingPayload: endpoint.signingPayload };
}
