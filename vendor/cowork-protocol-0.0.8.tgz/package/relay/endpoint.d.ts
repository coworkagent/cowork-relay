export const RELAY_ENDPOINT_PROTOCOL: 'cowork.relay.endpoint/1';
export const RELAY_PAIRING_PROTOCOL: 'cowork.pairing/1-relay';
export const RELAY_ENDPOINT_PATH: '/remote/v1/relay/endpoint';
export const RELAY_ENDPOINT_LIFETIME_SECONDS: 120;
export const RELAY_ENDPOINT_MAX_BYTES: 8192;
export interface RelayEndpoint {
  protocol: typeof RELAY_ENDPOINT_PROTOCOL; hostId: string; relayOrigin: string; relayHostId: string;
  httpsOrigin: string; certificateSha256: string; issuedAt: number; expiresAt: number; signature: string;
}
export interface RelayEndpointBinding { hostId: string; relayOrigin: string; relayHostId: string }
export interface RelayEndpointCandidate {
  record: RelayEndpoint; hostId: string; httpsOrigin: string; certificateSha256: string; expiresAt: number; signingPayload: string;
}
export interface RelayInvitation {
  protocol: typeof RELAY_PAIRING_PROTOCOL; endpoint: RelayEndpoint; trustAnchorDerBase64: string;
  pairingId: string; invitationSecret: string; expiresAt: string;
}
export function relayEndpointSigningPayload(value: Omit<RelayEndpoint, 'signature'>): string;
export function parseRelayEndpoint(value: unknown, expected: RelayEndpointBinding, nowMs?: number): RelayEndpointCandidate;
export function parseRelayInvitation(value: unknown, expectedRelay: Omit<RelayEndpointBinding, 'hostId'>, nowMs?: number): RelayInvitation & { signingPayload: string };
